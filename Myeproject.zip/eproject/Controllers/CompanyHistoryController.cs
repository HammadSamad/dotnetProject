﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanyHistoryController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;
        private readonly IConfiguration _config;

        public CompanyHistoryController(StarSecuritiesContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        [HttpPost]
        public async Task<IActionResult> AddCompanyHistory(CompanyHistory companyHistory)
        {
            try
            {
                if (companyHistory != null && companyHistory.PhotoUrl != null)
                {
                    var uploadPath = _config["StoredFilesPath"];

                    if (!Directory.Exists(uploadPath))
                        Directory.CreateDirectory(uploadPath);

                    var extention = Path.GetExtension(companyHistory.PhotoUrl.FileName);
                    var imageName = Guid.NewGuid().ToString() + extention;
                    var filePath = Path.Combine(uploadPath, imageName);
                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await companyHistory.PhotoUrl.CopyToAsync(stream);
                    }

                    var companyHistoryData = new CompanyHistory
                    {
                        FoundedDate = companyHistory.FoundedDate,
                        HistoryDescription = companyHistory.HistoryDescription,
                        Location = companyHistory.Location,
                        PhotoUrl = imageName,
                        CreatedAt = DateTime.Now,
                        UpdatedAt = DateTime.Now
                    };

                    _context.BoardOfDirectors.Add(companyHistoryData);
                    _context.SaveChanges();
                    return Ok("Board of Director added successfully");

                }
                return StatusCode(204);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpPut]
        public async Task<IActionResult> UpdateBoardofDirector(BoardOfDirectorCreate updateBoardOfDirector, int id)
        {
            try
            {
                var editBoardOfDirector = await _context.BoardOfDirectors.FindAsync(id);
                if (editBoardOfDirector == null)
                    return NotFound("Board of Director not found");

                // Always update non-image fields
                editBoardOfDirector.Name = updateBoardOfDirector.Name;
                editBoardOfDirector.Designation = updateBoardOfDirector.Designation;
                editBoardOfDirector.Bio = updateBoardOfDirector.Bio;
                editBoardOfDirector.UpdatedAt = DateTime.Now;

                // Only update image if a new one is uploaded
                if (updateBoardOfDirector.PhotoUrl != null && updateBoardOfDirector.PhotoUrl.Length > 0)
                {
                    var uploadPath = _config["StoredFilesPath"];
                    if (!Directory.Exists(uploadPath))
                        Directory.CreateDirectory(uploadPath);

                    var extension = Path.GetExtension(updateBoardOfDirector.PhotoUrl.FileName);
                    var imageName = Guid.NewGuid().ToString() + extension;
                    var filePath = Path.Combine(uploadPath, imageName);

                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await updateBoardOfDirector.PhotoUrl.CopyToAsync(stream);
                    }

                    // Optional: delete old image if it exists
                    if (!string.IsNullOrEmpty(editBoardOfDirector.PhotoUrl))
                    {
                        var oldImagePath = Path.Combine(uploadPath, editBoardOfDirector.PhotoUrl);
                        if (System.IO.File.Exists(oldImagePath))
                        {
                            System.IO.File.Delete(oldImagePath);
                        }
                    }

                    // Assign the new image
                    editBoardOfDirector.PhotoUrl = imageName;
                }

                _context.BoardOfDirectors.Update(editBoardOfDirector);
                await _context.SaveChangesAsync();

                return Ok("Board of Director updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


        [HttpDelete]
        public IActionResult DelBoardOfDirector(int id)
        {
            try
            {
                var delboardOfDirector = _context.BoardOfDirectors.Find(id);
                if (delboardOfDirector != null)
                {
                    _context.BoardOfDirectors.Remove(delboardOfDirector);
                    _context.SaveChanges();
                    return Ok("Board of Director deleted successfully");
                }
                return StatusCode(204);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpGet]
        public IActionResult GetBoardOfDirectors()
        {
            try
            {
                var boardOfDirectors = _context.BoardOfDirectors.ToList();
                if (boardOfDirectors != null && boardOfDirectors.Count > 0)
                {
                    return Ok(boardOfDirectors);
                }
                return StatusCode(204);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }

        }

        [HttpGet("GetBODWithId")]
        public IActionResult GetBoardOfDirectorById(int id)
        {
            try
            {
                var data = _context.BoardOfDirectors.Where(bod => bod.DirectorId == id).Select(bod => new BoardOfDirectorDTO
                {
                    DirectorId = bod.DirectorId,
                    Name = bod.Name,
                    Designation = bod.Designation,
                    Bio = bod.Bio,
                    PhotoUrl = bod.PhotoUrl,
                    CreatedAt = bod.CreatedAt
                }).FirstOrDefault();
                return Ok(data);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


    }
}
