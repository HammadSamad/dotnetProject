﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GradeController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;

        public GradeController(StarSecuritiesContext context)
        {
            _context = context;
        }

        [HttpPost]
        public IActionResult AddGrade(Grade grade)
        {
            try
            {
                if(grade != null)
                {
                    var grades = _context.Grades.Add(grade);
                    _context.SaveChanges();
                }
                return Ok("Grade added successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpPut]
        public IActionResult UpdateGrade(Grade grade, int id)
        {
            try
            {
                var editGrade = _context.Grades.Find(id);
                if (editGrade != null)
                {
                    editGrade.GradeName = grade.GradeName;
                }
                _context.SaveChanges();
                return Ok("Grade updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpDelete]
        public IActionResult DeleteGrade(int id)
        {
            try
            {
                var deleteGrade = _context.Grades.Find(id);
                if (deleteGrade != null)
                {
                    _context.Grades.Remove(deleteGrade);
                    _context.SaveChanges();
                }
                return Ok("Grade deleted successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpGet]
        public IActionResult GetAllGrades()
        {
            try
            {
                var grades = _context.Grades.ToList();
                return Ok(grades);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpGet("GetGradeById")]
        public IActionResult GetGradeById(int id)
        {
            try
            {
                var grade = _context.Grades.Find(id);
                if (grade != null)
                {
                    return Ok(grade);
                }
                return NotFound("Grade not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

    }
}
