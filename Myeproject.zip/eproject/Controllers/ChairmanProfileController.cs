﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChairmanProfileController : ControllerBase
    {

        private readonly StarSecuritiesContext _context;
        private readonly IConfiguration _config;

        public ChairmanProfileController(StarSecuritiesContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        [HttpPost]
        public async Task<IActionResult> AddChairmanProfile(ChairmanProfileCreate chairmanProfile)
        {
            try
            {
                if (chairmanProfile != null && chairmanProfile.PhotoUrl != null)
                {
                    var uploadPath = _config["StoredFilesPath"];

                    if (!Directory.Exists(uploadPath))
                        Directory.CreateDirectory(uploadPath);

                    var extention = Path.GetExtension(chairmanProfile.PhotoUrl.FileName);
                    var imageName = Guid.NewGuid().ToString() + extention;
                    var filePath = Path.Combine(uploadPath, imageName);
                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await chairmanProfile.PhotoUrl.CopyToAsync(stream);
                    }

                    var chairmanProfileData = new ChairmanProfile
                    {
                        Name = chairmanProfile.Name,
                        Bio = chairmanProfile.Bio,
                        PhotoUrl = imageName,
                        CreatedAt = DateTime.Now,
                        UpdatedAt = DateTime.Now
                    };

                    _context.ChairmanProfiles.Add(chairmanProfileData);
                    _context.SaveChanges();
                    return Ok("Chairman profile added successfully");

                }
                return StatusCode(204);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpPut]
        public async Task<IActionResult> UpdateChairmanProfile(ChairmanProfileCreate updateChairmanProfile, int id)
        {
            try
            {
                var editChairmanProfile = await _context.ChairmanProfiles.FindAsync(id);
                if (editChairmanProfile == null)
                    return NotFound("Chairman profile not found");

                // Always update these fields
                editChairmanProfile.Name = updateChairmanProfile.Name;
                editChairmanProfile.Bio = updateChairmanProfile.Bio;
                editChairmanProfile.UpdatedAt = DateTime.Now;

                // Only update image if a new one is uploaded
                if (updateChairmanProfile.PhotoUrl != null && updateChairmanProfile.PhotoUrl.Length > 0)
                {
                    var uploadPath = _config["StoredFilesPath"];
                    if (!Directory.Exists(uploadPath))
                        Directory.CreateDirectory(uploadPath);

                    var extension = Path.GetExtension(updateChairmanProfile.PhotoUrl.FileName);
                    var imageName = Guid.NewGuid().ToString() + extension;
                    var filePath = Path.Combine(uploadPath, imageName);

                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await updateChairmanProfile.PhotoUrl.CopyToAsync(stream);
                    }

                    // Optional: delete old image (if needed)
                    if (!string.IsNullOrEmpty(editChairmanProfile.PhotoUrl))
                    {
                        var oldImagePath = Path.Combine(uploadPath, editChairmanProfile.PhotoUrl);
                        if (System.IO.File.Exists(oldImagePath))
                        {
                            System.IO.File.Delete(oldImagePath);
                        }
                    }

                    editChairmanProfile.PhotoUrl = imageName;
                }

                _context.ChairmanProfiles.Update(editChairmanProfile);
                await _context.SaveChangesAsync();

                return Ok("Chairman profile updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


        [HttpDelete]
        public IActionResult DelChairmanProfile(int id)
        {
            try
            {
                var delChairmanProfile = _context.ChairmanProfiles.Find(id);
                if (delChairmanProfile != null)
                {
                    _context.ChairmanProfiles.Remove(delChairmanProfile);
                    _context.SaveChanges();
                    return Ok("Chairman profile deleted successfully");
                }
                return StatusCode(204);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpGet]
        public IActionResult GetChairmanProfile()
        {
            try
            {
                var chairmanProfile = _context.ChairmanProfiles.ToList();
                if (chairmanProfile != null && chairmanProfile.Count > 0)
                {
                    return Ok(chairmanProfile);
                }
                return StatusCode(204);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }

        }

        [HttpGet("getCPwithId")]
        public IActionResult GetChairmanProfileById(int id)
        {
            try
            {
                var data = _context.ChairmanProfiles.Where(bod => bod.ChairmanId == id).Select(bod => new ChairmanProfileDTO
                {
                    ChairmanId = bod.ChairmanId,
                    Name = bod.Name,
                    Bio = bod.Bio,
                    PhotoUrl = bod.PhotoUrl,
                    CreatedAt = bod.CreatedAt
                }).FirstOrDefault();
                return Ok(data);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

    }
}
