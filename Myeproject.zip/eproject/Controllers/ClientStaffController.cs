﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientStaffController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;

        public ClientStaffController(StarSecuritiesContext context)
        {
            _context = context;
        }

        [HttpPost]
        public IActionResult AddClientStaff(ClientStaffCreate clientStaff)
        {
            try
            {
                if (clientStaff != null)
                {
                    var clientsStaff = new ClientStaff
                    {
                        ClientId = clientStaff.ClientId,
                        EmployeeId = clientStaff.EmployeeId,
                        IsDeleted = false,
                        CreatedAt = DateTime.Now,
                        UpdatedAt = DateTime.Now
                    };
                    _context.SaveChanges();
                }
                return Ok("Client staff added successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpPut]
        public IActionResult UpdateClientStaff(ClientStaffCreate clientStaff, int id)
        {
            try
            {
                var editClientStaff = _context.ClientStaffs.Find(id);
                if (editClientStaff != null)
                {
                    editClientStaff.ClientId = clientStaff.ClientId;
                    editClientStaff.EmployeeId = clientStaff.EmployeeId;
                    editClientStaff.UpdatedAt = clientStaff.UpdatedAt;
                    _context.SaveChanges();
                    return Ok("Client staff updated successfully");
                }
                return NotFound("Client staff not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpDelete]
        public IActionResult DeleteClientService(int id)
        {
            try
            {
                var deleteClientStaff = _context.ClientStaffs.Find(id);
                if (deleteClientStaff != null)
                {
                    deleteClientStaff.IsDeleted = true;
                    deleteClientStaff.UpdatedAt = DateTime.Now;
                    _context.SaveChanges();
                    return Ok("Client staff deleted successfully");
                }
                return NotFound("Client staff not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpGet]
        public IActionResult GetClientStaff()
        {
            try {
                var clientStaff = _context.ClientStaffs.Include(cs => cs.Client).Include(cs => cs.Employee).Where(cs => cs.IsDeleted == false).Select(cs => new ClientStaffDTO
                {
                    ClientStaffId = cs.ClientStaffId,
                    ClientId = cs.ClientId,
                    ClientName = cs.Client.ClientName,
                    EmployeeId = cs.EmployeeId,
                    Name = cs.Employee.EmployeeName,
                    IsDeleted = cs.IsDeleted,
                    CreatedAt = cs.CreatedAt,
                    UpdatedAt = cs.UpdatedAt
                });
                return Ok(clientStaff);
            }
            
            catch (Exception error)
            {
                return BadRequest(error.Message);
    }
}

        [HttpGet("GetCSById")]
        public IActionResult GetClientStaffById(int id)
        {
            try
            {
                var clientStaff = _context.ClientStaffs.Include(cs => cs.Client).Include(cs => cs.Employee).Where(cs => cs.IsDeleted == false && cs.ClientStaffId == id).Select(cs => new ClientStaffDTO
                {
                    ClientStaffId = cs.ClientStaffId,
                    ClientId = cs.ClientId,
                    ClientName = cs.Client.ClientName,
                    EmployeeId = cs.EmployeeId,
                    Name = cs.Employee.EmployeeName,
                    IsDeleted = cs.IsDeleted,
                    CreatedAt = cs.CreatedAt,
                    UpdatedAt = cs.UpdatedAt
                }).FirstOrDefault();
                if (clientStaff != null)
                {
                    return Ok(clientStaff);
                }
                return NotFound("Client staff not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


    }
}
