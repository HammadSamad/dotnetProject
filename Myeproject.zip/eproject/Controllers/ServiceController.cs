﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServiceController : ControllerBase
    {

        private readonly StarSecuritiesContext _context;

        public ServiceController(StarSecuritiesContext context)
        {
            _context = context;
        }

        [HttpPost]
        public IActionResult AddService(Service service)
        {
            try
            {
                if(service != null)
                {
                    var services = _context.Services.Add(service);
                    _context.SaveChanges();
                }
                return Ok("Service added successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpPut]
        public IActionResult UpdateService(Service service,int id)
        {
            try
            {
                var editService = _context.Services.Find(id);
                if(editService != null)
                {
                    editService.ServiceType = service.ServiceType;
                    editService.ServiceName = service.ServiceName;
                    editService.Description = service.Description;
                    _context.Services.Update(editService);
                    _context.SaveChanges();
                }
                return Ok("Service updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpDelete]
        public IActionResult DeleteService(int id)
        {
            try
            {
                var deleteService = _context.Services.Find(id);
                if(deleteService != null)
                {
                    deleteService.IsDeleted = true;
                    _context.Services.Update(deleteService);
                    _context.SaveChanges();
                }
                return Ok("Service deleted successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpGet]
        public IActionResult GetService()
        {
            try
            {
                var services = _context.Services.Where(s => s.IsDeleted == false).ToList();
                return Ok(services);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpGet("GetSById")]
            public IActionResult GetServiceById(int id)
        {
            try
            {
                var service = _context.Services.Find(id);
                if(service != null && service.IsDeleted == false)
                {
                    return Ok(service);
                }
                return NotFound("Service Not Found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }




    }
}
