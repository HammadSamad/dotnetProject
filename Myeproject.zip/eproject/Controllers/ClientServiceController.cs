﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientServiceController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;

        public ClientServiceController(StarSecuritiesContext context)
        {
            _context = context;
        }

        [HttpPost]
        public IActionResult AddClientService(ClientServiceCreate clientService)
        {
            try
            {
                if(clientService != null)
                {
                    var clientServices = new ClientService
                    {
                        ClientId = clientService.ClientId,
                        ServiceId = clientService.ServiceId,
                        IsDeleted = false,
                        CreatedAt = DateTime.Now,
                        UpdatedAt = DateTime.Now
                    };
                    _context.SaveChanges();
                }
                    return Ok("Client Service Added Successfully");
                
            }
            catch(Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpPut]
        public IActionResult UpdateClientService(ClientServiceCreate clientService, int id)
        {
            try
            {
                var editClientService = _context.ClientServices.Find(id);
                if (editClientService != null)
                {
                    editClientService.ClientId = clientService.ClientId;
                    editClientService.ServiceId = clientService.ServiceId;
                    editClientService.UpdatedAt = DateTime.Now;
                }
                _context.SaveChanges();
                return Ok("Client Service updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpDelete]
        public IActionResult DeleteClientService(int id)
        {
            try
            {
                var deleteClientService = _context.ClientServices.Find(id);
                if (deleteClientService != null)
                {
                    deleteClientService.IsDeleted = true;
                    deleteClientService.UpdatedAt = DateTime.Now;
                }
                _context.SaveChanges();
                return Ok("Client Service deleted successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpGet]
        public IActionResult GetClientServices()
        {
            try
            {
                var clientData = _context.ClientServices.Include(cd => cd.Client).Include(cd => cd.Service).Where(cd => cd.IsDeleted == false).Select(cd => new ClientServiceDTO
                {
                    ClientServiceId = cd.ClientServiceId,
                    ClientId = cd.ClientId,
                    ClientName = cd.Client.ClientName,
                    ServiceId = cd.ServiceId,
                    ServiceName = cd.Service.ServiceName,
                    IsDeleted = cd.IsDeleted,
                    CreatedAt = cd.CreatedAt,
                    UpdatedAt = cd.UpdatedAt
                });
                return Ok(clientData);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpGet("GetCSById")]
        public IActionResult GetClientServiceById(int id)
        {
            try
            {
                var clientService = _context.ClientServices.Include(cd => cd.Client).Include(cd => cd.Service).Where(cs => cs.ClientServiceId == id && cs.IsDeleted == false).FirstOrDefault();
                if (clientService != null)
                {
                    return Ok(clientService);
                }
                return NotFound("Client Service not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }



    }
}
