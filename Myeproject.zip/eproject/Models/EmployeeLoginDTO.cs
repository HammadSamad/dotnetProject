﻿namespace eproject.Models
{
    public class EmployeeLoginDTO
    {
    }
}
