﻿using System;
using System.Collections.Generic;

namespace eproject.Models;

public partial class BoardOfDirector
{
    public int DirectorId { get; set; }

    public string Name { get; set; } = null!;

    public string Designation { get; set; } = null!;

    public string Bio { get; set; } = null!;

    public string? PhotoUrl { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }
}
