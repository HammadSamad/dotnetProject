﻿using System;
using System.Collections.Generic;

namespace eproject.Models;

public partial class Vacancy
{
    public int VacancyId { get; set; }

    public string Title { get; set; } = null!;

    public string Department { get; set; } = null!;

    public string Description { get; set; } = null!;

    public string Status { get; set; } = null!;

    public bool? IsDeleted { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }
}
