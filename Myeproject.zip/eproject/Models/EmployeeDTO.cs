﻿namespace eproject.Models
{
    public class EmployeeDTO
    {
    }
}
