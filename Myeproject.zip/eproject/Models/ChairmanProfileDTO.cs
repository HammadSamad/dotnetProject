﻿namespace eproject.Models
{
    public class ChairmanProfileDTO
    {
        public int ChairmanId { get; set; }

        public string Name { get; set; } = null!;

        public string Bio { get; set; } = null!;

        public string? PhotoUrl { get; set; }

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }
}
