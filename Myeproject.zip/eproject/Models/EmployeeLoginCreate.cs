﻿namespace eproject.Models
{
    public class EmployeeLoginCreate
    {
    }
}
