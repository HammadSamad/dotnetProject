﻿namespace eproject.Models
{
    public class TestimonialDTO
    {
    }
}
