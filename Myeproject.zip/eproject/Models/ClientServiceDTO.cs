﻿using System.Text.Json.Serialization;

namespace eproject.Models
{
    public class ClientServiceDTO
    {
        public int ClientServiceId { get; set; }

        public int ClientId { get; set; }

        public string? ClientName { get; set; }

        public int ServiceId { get; set; }

        public string? ServiceName { get; set; } 

        public bool? IsDeleted { get; set; }

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }

    }
}
