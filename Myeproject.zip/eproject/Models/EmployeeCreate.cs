﻿namespace eproject.Models
{
    public class EmployeeCreate
    {
    }
}
