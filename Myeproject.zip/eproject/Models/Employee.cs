﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace eproject.Models;

public partial class Employee
{
    public int EmployeeId { get; set; }

    public string EmployeeCode { get; set; } = null!;

    public string EmployeeName { get; set; } = null!;

    public string Address { get; set; } = null!;

    public string ContactNumber { get; set; } = null!;

    public string EducationalQualification { get; set; } = null!;

    public int DepartmentId { get; set; }

    public int RoleId { get; set; }

    public int GradeId { get; set; }

    public string? Achievements { get; set; }

    public bool? IsDeleted { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<ClientStaff> ClientStaffs { get; set; } = new List<ClientStaff>();

    [JsonIgnore]
    public virtual Department? Department { get; set; } = null!;

    public virtual ICollection<EmployeeLogin> EmployeeLogins { get; set; } = new List<EmployeeLogin>();

    [JsonIgnore]
    public virtual Grade? Grade { get; set; } = null!;

    [JsonIgnore]
    public virtual Role? Role { get; set; } = null!;
}
