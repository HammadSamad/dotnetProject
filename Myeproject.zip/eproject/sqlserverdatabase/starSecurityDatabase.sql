-- =============================================
-- DATABASE CREATION
-- =============================================
CREATE DATABASE star_securities;
GO
USE star_securities;
GO

-- =============================================
-- TABLE: company_history
-- =============================================
CREATE TABLE company_history (
    history_id INT PRIMARY KEY IDENTITY(1,1),
    founded_date DATE NOT NULL,
    photo_url VARCHAR(255),
    history_description VARCHAR(MAX) NOT NULL,
    location VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO

-- =============================================
-- TABLE: chairman_profile
-- =============================================
CREATE TABLE chairman_profile (
    chairman_id INT PRIMARY KEY IDENTITY(1,1),
    name VARCHAR(100) NOT NULL,
    bio VARCHAR(MAX) NOT NULL,
    photo_url VARCHAR(255),
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO

-- =============================================
-- TABLE: board_of_directors
-- =============================================
CREATE TABLE board_of_directors (
    director_id INT PRIMARY KEY IDENTITY(1,1),
    name VARCHAR(100) NOT NULL,
    designation VARCHAR(100) NOT NULL,
    bio VARCHAR(MAX) NOT NULL,
    photo_url VARCHAR(255),
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO

-- =============================================
-- TABLE: services (Soft Delete Enabled)
-- =============================================
CREATE TABLE services (
    service_id INT PRIMARY KEY IDENTITY(1,1),
    service_type VARCHAR(50) NOT NULL,
    service_name VARCHAR(100) NOT NULL,
    description VARCHAR(MAX) NOT NULL,
    is_deleted BIT DEFAULT 0,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO

CREATE TRIGGER trg_services_update
ON services
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE s
    SET updated_at = GETDATE()
    FROM services s
    INNER JOIN inserted i ON s.service_id = i.service_id;
END;
GO

-- =============================================
-- TABLE: regions
-- =============================================
CREATE TABLE regions (
    region_id INT PRIMARY KEY IDENTITY(1,1),
    region_name VARCHAR(50) NOT NULL CHECK (region_name IN ('NORTH', 'WEST', 'EAST', 'SOUTH')),
    address VARCHAR(MAX) NOT NULL,
    contact_person VARCHAR(100) NOT NULL,
    contact_number VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO

-- =============================================
-- TABLE: roles
-- =============================================
CREATE TABLE roles (
    role_id   INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL UNIQUE
);
GO

INSERT INTO roles (role_name) VALUES ('ADMIN'), ('STAFF');
GO



-- =============================================
-- TABLE: departments
-- =============================================
CREATE TABLE departments (
    department_id INT PRIMARY KEY IDENTITY(1,1),
    department_name VARCHAR(50) UNIQUE NOT NULL
);
GO

-- =============================================
-- TABLE: grades
-- =============================================
CREATE TABLE grades (
    grade_id INT PRIMARY KEY IDENTITY(1,1),
    grade_name VARCHAR(50) UNIQUE NOT NULL
);
GO

-- =============================================
-- TABLE: employees (Soft Delete Enabled)
-- =============================================
CREATE TABLE employees (
    employee_id INT PRIMARY KEY IDENTITY(1,1),
    employee_code VARCHAR(50) UNIQUE NOT NULL,
    employee_name VARCHAR(100) NOT NULL,
    address VARCHAR(255) NOT NULL,
    contact_number VARCHAR(20) NOT NULL CHECK (contact_number LIKE '+%' OR contact_number LIKE '%[0-9]%'),
    educational_qualification VARCHAR(255) NOT NULL,
    department_id INT NOT NULL,
    role_id INT NOT NULL,
    grade_id INT NOT NULL,
    achievements VARCHAR(MAX),
    is_deleted BIT DEFAULT 0,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (role_id) REFERENCES roles(role_id),
    FOREIGN KEY (department_id) REFERENCES departments(department_id),
    FOREIGN KEY (grade_id) REFERENCES grades(grade_id)
);
GO

-- =============================================
-- TRIGGER: employees update
-- =============================================
CREATE TRIGGER trg_employees_update
ON employees
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE e
    SET updated_at = GETDATE()
    FROM employees e
    INNER JOIN inserted i ON e.employee_id = i.employee_id;
END;
GO


-- =============================================
-- TABLE: clients (Soft Delete Enabled)
-- =============================================
CREATE TABLE clients (
    client_id INT PRIMARY KEY IDENTITY(1,1),
    client_name VARCHAR(100) NOT NULL,
    is_deleted BIT DEFAULT 0,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO

CREATE TRIGGER trg_clients_update
ON clients
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE c
    SET updated_at = GETDATE()
    FROM clients c
    INNER JOIN inserted i ON c.client_id = i.client_id;
END;
GO

-- =============================================
-- TABLE: client_services (Soft Delete Enabled)
-- =============================================
CREATE TABLE client_services (
    client_service_id INT PRIMARY KEY IDENTITY(1,1),
    client_id INT NOT NULL,
    service_id INT NOT NULL,
    is_deleted BIT DEFAULT 0,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (client_id) REFERENCES clients(client_id),
    FOREIGN KEY (service_id) REFERENCES services(service_id)
);
GO

-- =============================================
-- TABLE: client_staff (Soft Delete Enabled)
-- =============================================
CREATE TABLE client_staff (
    client_staff_id INT PRIMARY KEY IDENTITY(1,1),
    client_id INT NOT NULL,
    employee_id INT NOT NULL,
    is_deleted BIT DEFAULT 0,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (client_id) REFERENCES clients(client_id),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
);
GO

-- =============================================
-- TABLE: vacancies (Soft Delete Enabled)
-- =============================================
CREATE TABLE vacancies (
    vacancy_id INT PRIMARY KEY IDENTITY(1,1),
    title VARCHAR(100) NOT NULL,
    department VARCHAR(50) NOT NULL,
    description VARCHAR(MAX) NOT NULL,
    status VARCHAR(50) DEFAULT 'OPEN' NOT NULL CHECK (status IN ('OPEN', 'FILLED', 'CLOSED')),
    is_deleted BIT DEFAULT 0,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO

CREATE TRIGGER trg_vacancies_update
ON vacancies
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE v
    SET updated_at = GETDATE()
    FROM vacancies v
    INNER JOIN inserted i ON v.vacancy_id = i.vacancy_id;
END;
GO

-- =============================================
-- TABLE: employee_logins (Soft Delete Enabled)
-- =============================================
CREATE TABLE employee_logins (
    login_id INT PRIMARY KEY IDENTITY(1,1),
    employee_id INT NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role_id INT NOT NULL,
    is_deleted BIT DEFAULT 0,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
);
GO

-- =============================================
-- TABLE: testimonials (Soft Delete Enabled)
-- =============================================
CREATE TABLE testimonials (
    testimonial_id INT PRIMARY KEY IDENTITY(1,1),
    client_id INT NOT NULL,
    testimonial_text VARCHAR(MAX) NOT NULL,
    author_name VARCHAR(100) NOT NULL,
    is_deleted BIT DEFAULT 0,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (client_id) REFERENCES clients(client_id)
);
GO

-- =============================================
-- TABLE: contact_inquiries
-- =============================================
CREATE TABLE contact_inquiries (
    inquiry_id INT PRIMARY KEY IDENTITY(1,1),
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    message VARCHAR(MAX) NOT NULL,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO
