-- =============================================
-- DATABASE CREATION
-- =============================================
CREATE DATABASE star_securities;
GO
USE star_securities;
GO

-- =============================================
-- TABLE: company_history
-- =============================================
CREATE TABLE company_history (
    history_id INT PRIMARY KEY IDENTITY(1,1),
    founded_date DATE NOT NULL,
    photo_url NVARCHAR(255),
    history_description NVARCHAR(MAX) NOT NULL,
    location NVARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO

-- =============================================
-- TABLE: chairman_profile
-- =============================================
CREATE TABLE chairman_profile (
    chairman_id INT PRIMARY KEY IDENTITY(1,1),
    name NVARCHAR(100) NOT NULL,
    bio NVARCHAR(MAX) NOT NULL,
    photo_url NVARCHAR(255),
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO

-- =============================================
-- TABLE: board_of_directors
-- =============================================
CREATE TABLE board_of_directors (
    director_id INT PRIMARY KEY IDENTITY(1,1),
    name NVARCHAR(100) NOT NULL,
    designation NVARCHAR(100) NOT NULL,
    bio NVARCHAR(MAX) NOT NULL,
    photo_url NVARCHAR(255),
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO

-- =============================================
-- TABLE: services (Soft Delete Enabled)
-- =============================================
CREATE TABLE services (
    service_id INT PRIMARY KEY IDENTITY(1,1),
    photo_url NVARCHAR(255),
    service_type NVARCHAR(50) NOT NULL,
    service_name NVARCHAR(100) NOT NULL,
    description NVARCHAR(MAX) NOT NULL,
    is_deleted BIT NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO

CREATE TRIGGER trg_services_update
ON services
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE s
    SET updated_at = GETDATE()
    FROM services s
    INNER JOIN inserted i ON s.service_id = i.service_id;
END;
GO

-- =============================================
-- TABLE: branches
-- =============================================
CREATE TABLE branches (
    branch_id INT PRIMARY KEY IDENTITY(1,1),
    branch_name NVARCHAR(50) NOT NULL,
    address NVARCHAR(MAX) NOT NULL,
    contact_number NVARCHAR(20) NOT NULL
        CHECK (contact_number LIKE '+[0-9]%' OR contact_number LIKE '[0-9]%'),
    email NVARCHAR(100) NOT NULL UNIQUE
        CHECK (email LIKE '_%@_%._%'),
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO

-- =============================================
-- TABLE: regions
-- =============================================
CREATE TABLE regions (
    region_id INT PRIMARY KEY IDENTITY(1,1),
    region_name NVARCHAR(50) NOT NULL CHECK (region_name IN ('NORTH', 'WEST', 'EAST', 'SOUTH')),
    branch_id INT NOT NULL,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id)
);
GO

-- =============================================
-- TABLE: roles
-- =============================================
CREATE TABLE roles (
    role_id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    role_name NVARCHAR(50) NOT NULL UNIQUE
);
GO

INSERT INTO roles (role_name) VALUES ('ADMIN'), ('STAFF');
GO

-- =============================================
-- TABLE: departments
-- =============================================
CREATE TABLE departments (
    department_id INT PRIMARY KEY IDENTITY(1,1),
    department_name NVARCHAR(50) UNIQUE NOT NULL
);
GO

-- =============================================
-- TABLE: grades
-- =============================================
CREATE TABLE grades (
    grade_id INT PRIMARY KEY IDENTITY(1,1),
    grade_name NVARCHAR(50) UNIQUE NOT NULL
);
GO

-- =============================================
-- TABLE: employees (Soft Delete Enabled)
-- =============================================
CREATE TABLE employees (
    employee_id INT PRIMARY KEY IDENTITY(1,1),

    -- Auto-generate Employee Code: EMP-0001, EMP-0002, ...
    employee_code AS ('EMP-' + RIGHT('0000' + CAST(employee_id AS VARCHAR(4)), 4)) PERSISTED,

    photo_url NVARCHAR(255),
    employee_name NVARCHAR(100) NOT NULL UNIQUE,
    employee_email NVARCHAR(255) NOT NULL UNIQUE
        CHECK (employee_email LIKE '_%@_%._%'),
    employee_address NVARCHAR(255) NOT NULL,
    contact_number NVARCHAR(20) NOT NULL
        CHECK (contact_number LIKE '+[0-9]%' OR contact_number LIKE '[0-9]%'),
    educational_qualification NVARCHAR(255) NOT NULL,
    department_id INT NOT NULL,
    role_id INT NOT NULL,
    grade_id INT NOT NULL,
    achievements NVARCHAR(MAX),
    is_deleted BIT NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (role_id) REFERENCES roles(role_id),
    FOREIGN KEY (department_id) REFERENCES departments(department_id),
    FOREIGN KEY (grade_id) REFERENCES grades(grade_id)
);
GO

CREATE UNIQUE INDEX IX_employees_employee_code ON employees(employee_code);
GO

CREATE TRIGGER trg_employees_update
ON employees
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE e
    SET updated_at = GETDATE()
    FROM employees e
    INNER JOIN inserted i ON e.employee_id = i.employee_id;
END;
GO

-- =============================================
-- TABLE: clients (Soft Delete Enabled)
-- =============================================
CREATE TABLE clients (
    client_id INT PRIMARY KEY IDENTITY(1,1),
    client_name NVARCHAR(100) NOT NULL UNIQUE,
    client_email NVARCHAR(100) NOT NULL UNIQUE
        CHECK (client_email LIKE '_%@_%._%'),
    photo_url NVARCHAR(255),
    client_number NVARCHAR(20) NOT NULL
        CHECK (client_number LIKE '+[0-9]%' OR client_number LIKE '[0-9]%'),
    client_address NVARCHAR(255) NOT NULL,
    is_deleted BIT NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO

CREATE TRIGGER trg_clients_update
ON clients
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE c
    SET updated_at = GETDATE()
    FROM clients c
    INNER JOIN inserted i ON c.client_id = i.client_id;
END;
GO

-- =============================================
-- TABLE: client_services (Soft Delete Enabled)
-- =============================================
CREATE TABLE client_services (
    client_service_id INT PRIMARY KEY IDENTITY(1,1),
    client_id INT NOT NULL,
    service_id INT NOT NULL,
    is_deleted BIT NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (client_id) REFERENCES clients(client_id),
    FOREIGN KEY (service_id) REFERENCES services(service_id)
);
GO

-- =============================================
-- TABLE: client_staff (Soft Delete Enabled)
-- =============================================
CREATE TABLE client_staff (
    client_staff_id INT PRIMARY KEY IDENTITY(1,1),
    client_id INT NOT NULL,
    employee_id INT NOT NULL,
    is_deleted BIT NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (client_id) REFERENCES clients(client_id),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
);
GO

-- =============================================
-- TABLE: vacancies (Soft Delete Enabled)
-- =============================================
CREATE TABLE vacancies (
    vacancy_id INT PRIMARY KEY IDENTITY(1,1),
    title NVARCHAR(100) NOT NULL,
    department_id INT NOT NULL,
    description NVARCHAR(MAX) NOT NULL,
    opening_date DATE DEFAULT CAST(GETDATE() AS DATE),
    closing_date DATE,
    status NVARCHAR(50) NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'FILLED', 'CLOSED')),
    is_deleted BIT NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
);
GO

CREATE TRIGGER trg_vacancies_update
ON vacancies
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE v
    SET updated_at = GETDATE()
    FROM vacancies v
    INNER JOIN inserted i ON v.vacancy_id = i.vacancy_id;
END;
GO

-- =============================================
-- TABLE: logins (Soft Delete Enabled)
-- =============================================
CREATE TABLE logins (
    login_id INT PRIMARY KEY IDENTITY(1,1),
    employee_id INT NOT NULL,
    username NVARCHAR(50) UNIQUE NOT NULL,
    password_hash NVARCHAR(255) NOT NULL,
    is_deleted BIT NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
);
GO

-- =============================================
-- TABLE: testimonials (Soft Delete Enabled)
-- =============================================
CREATE TABLE testimonials (
    testimonial_id INT PRIMARY KEY IDENTITY(1,1),
    client_id INT NOT NULL,
    testimonial_text NVARCHAR(MAX) NOT NULL,
    author_name NVARCHAR(100) NOT NULL,
    is_deleted BIT NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (client_id) REFERENCES clients(client_id)
);
GO

-- =============================================
-- TABLE: contact_inquiries
-- =============================================
CREATE TABLE contact_inquiries (
    inquiry_id INT PRIMARY KEY IDENTITY(1,1),
    name NVARCHAR(100) NOT NULL,
    email NVARCHAR(100) NOT NULL
        CHECK (email LIKE '_%@_%._%'),
    phone NVARCHAR(20)
        CHECK (phone LIKE '+[0-9]%' OR phone LIKE '[0-9]%'),
    message NVARCHAR(MAX) NOT NULL,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO
