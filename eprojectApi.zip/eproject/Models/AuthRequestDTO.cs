﻿namespace eproject.Models
{
    public class AuthRequestDTO
    {
    }
}
