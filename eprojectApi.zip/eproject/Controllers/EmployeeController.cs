﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {

        private readonly StarSecuritiesContext _context;
        private readonly IConfiguration _config;

        public EmployeeController(StarSecuritiesContext context,IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        //-------------------------------------------------------------
        //---------------------------- POST ---------------------------
        //-------------------------------------------------------------

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddEmployee(EmployeeCreate employee)
        {
            try
            {
                if (employee != null && employee.PhotoUrl != null)
                {
                    var uploadPath = _config["StoredFilesPath"];

                    if (!Directory.Exists(uploadPath))
                        Directory.CreateDirectory(uploadPath);

                    var extention = Path.GetExtension(employee.PhotoUrl.FileName);
                    var imageName = Guid.NewGuid().ToString() + extention;
                    var filePath = Path.Combine(uploadPath, imageName);
                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await employee.PhotoUrl.CopyToAsync(stream);
                    }

                    var employees = new Employee
                    {
                        EmployeeCode = employee.EmployeeCode,
                        PhotoUrl = imageName,
                        EmployeeName = employee.EmployeeName,
                        EmployeeEmail = employee.EmployeeEmail,
                        EmployeeAddress = employee.EmployeeAddress,
                        ContactNumber = employee.ContactNumber,
                        EducationalQualification = employee.EducationalQualification,
                        DepartmentId = employee.DepartmentId,
                        RoleId = employee.RoleId,
                        GradeId = employee.GradeId,
                        Achievements = employee.Achievements,
                        IsDeleted = false,
                        CreatedAt = DateTime.Now,
                        UpdatedAt = DateTime.Now
                    };

                    _context.Employees.Add(employees);
                    _context.SaveChanges();

                }
                return Ok("Employee added successfully");

            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-------------------------------------------------------------
        //---------------------------- PUT ----------------------------
        //-------------------------------------------------------------

        [HttpPut]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateEmployee(EmployeeCreate employee)
        {
            try
            {
                var existingEmployee = _context.Employees.Find(employee.EmployeeId);
                if (existingEmployee == null)
                    return NotFound("Employee not found");

                // update non-image fields
                existingEmployee.EmployeeCode = employee.EmployeeCode;
                existingEmployee.EmployeeName = employee.EmployeeName;
                existingEmployee.EmployeeEmail = employee.EmployeeEmail;
                existingEmployee.EmployeeAddress = employee.EmployeeAddress;
                existingEmployee.ContactNumber = employee.ContactNumber;
                existingEmployee.EducationalQualification = employee.EducationalQualification;
                existingEmployee.DepartmentId = employee.DepartmentId;
                existingEmployee.RoleId = employee.RoleId;
                existingEmployee.GradeId = employee.GradeId;
                existingEmployee.Achievements = employee.Achievements;
                existingEmployee.UpdatedAt = DateTime.Now;

                // Only update image if a new one is uploaded
                if (employee.PhotoUrl != null && employee.PhotoUrl.Length > 0)
                {
                    var uploadPath = _config["StoredFilesPath"];
                    if (!Directory.Exists(uploadPath))
                        Directory.CreateDirectory(uploadPath);

                    var extension = Path.GetExtension(employee.PhotoUrl.FileName);
                    var imageName = Guid.NewGuid().ToString() + extension;
                    var filePath = Path.Combine(uploadPath, imageName);

                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await employee.PhotoUrl.CopyToAsync(stream);
                    }

                    // Optional: delete old image if it exists
                    if (!string.IsNullOrEmpty(existingEmployee.PhotoUrl))
                    {
                        var oldImagePath = Path.Combine(uploadPath, existingEmployee.PhotoUrl);
                        if (System.IO.File.Exists(oldImagePath))
                        {
                            System.IO.File.Delete(oldImagePath);
                        }
                    }

                    // Assign the new image
                    existingEmployee.PhotoUrl = imageName;
                }

                _context.Employees.Update(existingEmployee);
                await _context.SaveChangesAsync();

                return Ok("Employee updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-------------------------------------------------------------
        //--------------------------- DELETE --------------------------
        //-------------------------------------------------------------

        [HttpDelete]
        [Authorize(Roles = "Admin")]
        public IActionResult DeleteEmployee(int employeeId)
        {
            try
            {
                var existingEmployee = _context.Employees.Find(employeeId);
                if (existingEmployee != null)
                {
                    existingEmployee.IsDeleted = true;
                    existingEmployee.UpdatedAt = DateTime.Now;
                    _context.SaveChanges();
                    return Ok("Employee deleted successfully");
                }
                return NotFound("Employee not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-------------------------------------------------------------
        //---------------------------- GET ----------------------------
        //-------------------------------------------------------------

        [HttpGet]
        public IActionResult GetEmployees()
        {
            try
            {
                var employees = _context.Employees.Include(e => e.Department).Include(e => e.Role).Include(e => e.Grade).Where(e => e.IsDeleted == false).Select(e => new EmployeeDTO
                {
                    EmployeeId = e.EmployeeId,
                    EmployeeCode = e.EmployeeCode,
                    EmployeeName = e.EmployeeName,
                    EmployeeEmail = e.EmployeeEmail,
                    EmployeeAddress = e.EmployeeAddress,
                    PhotoUrl = e.PhotoUrl,
                    ContactNumber = e.ContactNumber,
                    EducationalQualification = e.EducationalQualification,
                    DepartmentId = e.DepartmentId,
                    DepartmentName = e.Department.DepartmentName,
                    RoleId = e.RoleId,
                    RoleName = e.Role.RoleName,
                    GradeId = e.GradeId,
                    GradeName = e.Grade.GradeName,
                    Achievements = e.Achievements,
                    IsDeleted = e.IsDeleted,
                    CreatedAt = e.CreatedAt,
                    UpdatedAt = e.UpdatedAt
                }).ToList();
                return Ok(employees);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-------------------------------------------------------------
        //------------------------- GET BY ID -------------------------
        //-------------------------------------------------------------

        [HttpGet("GetEById")]
        public IActionResult GetEmployeeById(int id)
        {
            try
            {
                var employee = _context.Employees.Include(e => e.Department).Include(e => e.Role).Include(e => e.Grade).Where(e => e.EmployeeId == id && e.IsDeleted == false).Select(e => new EmployeeDTO
                {
                    EmployeeId = e.EmployeeId,
                    EmployeeCode = e.EmployeeCode,
                    PhotoUrl = e.PhotoUrl,
                    EmployeeName = e.EmployeeName,
                    EmployeeEmail = e.EmployeeEmail,
                    EmployeeAddress = e.EmployeeAddress,
                    ContactNumber = e.ContactNumber,
                    EducationalQualification = e.EducationalQualification,
                    DepartmentId = e.DepartmentId,
                    DepartmentName = e.Department.DepartmentName,
                    RoleId = e.RoleId,
                    RoleName = e.Role.RoleName,
                    GradeId = e.GradeId,
                    GradeName = e.Grade.GradeName,
                    Achievements = e.Achievements,
                    IsDeleted = e.IsDeleted,
                    CreatedAt = e.CreatedAt,
                    UpdatedAt = e.UpdatedAt
                }).FirstOrDefault();
                if (employee != null)
                {
                    return Ok(employee);
                }
                return NotFound("Employee not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


    }
}
