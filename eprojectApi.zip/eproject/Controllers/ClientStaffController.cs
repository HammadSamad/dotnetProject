﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientStaffController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;

        public ClientStaffController(StarSecuritiesContext context)
        {
            _context = context;
        }

        //----------------------------------------------------------------
        //------------------------ POST ----------------------------------
        //----------------------------------------------------------------

        [HttpPost]
        public IActionResult AddClientStaff(ClientStaffCreate clientStaff)
        {
            try
            {
                if (clientStaff == null)
                {
                    return BadRequest("Invalid request");
                }

                //  Check if client exists
                var client = _context.Clients.FirstOrDefault(c => c.ClientId == clientStaff.ClientId);
                if (client == null)
                {
                    return NotFound("Client not found");
                }
                if (client.IsDeleted == true)
                {
                    return BadRequest("Cannot add staff to a deleted client.");
                }

                //  Check if employee exists
                var employee = _context.Employees.FirstOrDefault(e => e.EmployeeId == clientStaff.EmployeeId);
                if (employee == null)
                {
                    return NotFound("Employee not found");
                }
                if (employee.IsDeleted == true)
                {
                    return BadRequest("Cannot assign a deleted employee to a client.");
                }

                //  Add new ClientStaff
                var newClientStaff = new ClientStaff
                {
                    ClientId = clientStaff.ClientId,
                    EmployeeId = clientStaff.EmployeeId,
                    IsDeleted = false,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                _context.ClientStaffs.Add(newClientStaff);
                _context.SaveChanges();

                return Ok("Client staff added successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }



        //----------------------------------------------------------------
        //------------------------ PUT -----------------------------------
        //----------------------------------------------------------------

        [HttpPut]
        public IActionResult UpdateClientStaff(ClientStaffCreate updateClientStaff, int id)
        {
            try
            {
                var editClientStaff = _context.ClientStaffs.Find(id);
                if (editClientStaff == null)
                {
                    return NotFound("Client staff not found");
                }

                //  Check client
                var client = _context.Clients.FirstOrDefault(c => c.ClientId == updateClientStaff.ClientId);
                if (client == null)
                {
                    return NotFound("Client not found");
                }
                if (client.IsDeleted == true)
                {
                    return BadRequest("Cannot assign staff to a deleted client.");
                }

                //  Check employee
                var employee = _context.Employees.FirstOrDefault(e => e.EmployeeId == updateClientStaff.EmployeeId);
                if (employee == null)
                {
                    return NotFound("Employee not found");
                }
                if (employee.IsDeleted == true)
                {
                    return BadRequest("Cannot assign a deleted employee to a client.");
                }

                //  Update
                editClientStaff.ClientId = updateClientStaff.ClientId;
                editClientStaff.EmployeeId = updateClientStaff.EmployeeId;
                editClientStaff.UpdatedAt = DateTime.Now; 

                _context.SaveChanges();
                return Ok("Client staff updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


        //----------------------------------------------------------------
        //------------------------ DELETE --------------------------------
        //----------------------------------------------------------------

        [HttpDelete]
        public IActionResult DeleteClientService(int id)
        {
            try
            {
                var deleteClientStaff = _context.ClientStaffs.Find(id);
                if (deleteClientStaff != null)
                {
                    deleteClientStaff.IsDeleted = true;
                    deleteClientStaff.UpdatedAt = DateTime.Now;
                    _context.SaveChanges();
                    return Ok("Client staff deleted successfully");
                }
                return NotFound("Client staff not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ GET -----------------------------------
        //----------------------------------------------------------------

        [HttpGet]
        public IActionResult GetClientStaff()
        {
            try
            {
                var clientStaff = _context.ClientStaffs
                    .Include(cs => cs.Client)
                    .Include(cs => cs.Employee)
                    .Where(cs => cs.IsDeleted == false
                              && cs.Client.IsDeleted == false    
                              && cs.Employee.IsDeleted == false) 
                    .Select(cs => new ClientStaffDTO
                    {
                        ClientStaffId = cs.ClientStaffId,
                        ClientId = cs.ClientId,
                        ClientName = cs.Client.ClientName,
                        EmployeeId = cs.EmployeeId,
                        EmployeeName = cs.Employee.EmployeeName,
                        IsDeleted = cs.IsDeleted,
                        CreatedAt = cs.CreatedAt,
                        UpdatedAt = cs.UpdatedAt
                    })
                    .ToList();

                return Ok(clientStaff);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


        //----------------------------------------------------------------
        //------------------------ GET BY ID ------------------------------
        //----------------------------------------------------------------

        [HttpGet("GetCSById")]
        public IActionResult GetClientStaffById(int id)
        {
            try
            {
                var clientStaff = _context.ClientStaffs
                    .Include(cs => cs.Client)
                    .Include(cs => cs.Employee)
                    .Where(cs => cs.IsDeleted == false
                              && cs.Client.IsDeleted == false   
                              && cs.Employee.IsDeleted == false  
                              && cs.ClientStaffId == id)
                    .Select(cs => new ClientStaffDTO
                    {
                        ClientStaffId = cs.ClientStaffId,
                        ClientId = cs.ClientId,
                        ClientName = cs.Client.ClientName,
                        EmployeeId = cs.EmployeeId,
                        EmployeeName = cs.Employee.EmployeeName,
                        IsDeleted = cs.IsDeleted,
                        CreatedAt = cs.CreatedAt,
                        UpdatedAt = cs.UpdatedAt
                    })
                    .FirstOrDefault();

                if (clientStaff != null)
                {
                    return Ok(clientStaff);
                }

                return NotFound("Client staff not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }



    }
}
