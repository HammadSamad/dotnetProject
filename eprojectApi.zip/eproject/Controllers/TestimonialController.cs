﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestimonialController : ControllerBase
    {

        private readonly StarSecuritiesContext _context;

        public TestimonialController(StarSecuritiesContext context)
        {
            _context = context;
        }

        //-----------------------------------------------------------
        //----------------------- POST ------------------------------
        //-----------------------------------------------------------

        [HttpPost]
        public IActionResult AddTestimonial(TestimonialCreate testimonial)
        {
            try
            {
                var testimonials = new Testimonial
                {
                    ClientId = testimonial.ClientId,
                    TestimonialText = testimonial.TestimonialText,
                    AuthorName = testimonial.AuthorName,
                    IsDeleted = false,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };
                return Ok("Testimonial added successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //------------------------- PUT -----------------------------
        //---------------------------==------------------------------

        [HttpPut]
        public IActionResult UpdateTestimonial(TestimonialCreate testimonial,int id)
        {
            try
            {
                var existingTestimonial = _context.Testimonials.Find(id);
                if (existingTestimonial == null)
                {
                    return NotFound("Testimonial not found");
                }
                existingTestimonial.ClientId = testimonial.ClientId;
                existingTestimonial.TestimonialText = testimonial.TestimonialText;
                existingTestimonial.AuthorName = testimonial.AuthorName;
                existingTestimonial.UpdatedAt = DateTime.Now;
                _context.SaveChanges();
                return Ok("Testimonial updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //------------------------ DELETE ---------------------------
        //-----------------------------------------------------------

        [HttpDelete]
        public IActionResult DeleteTestimonial(int id)
        {
            try
            {
                var existingTestimonial = _context.Testimonials.Find(id);
                if (existingTestimonial == null)
                {
                    return NotFound("Testimonial not found");
                }
                existingTestimonial.IsDeleted = true;
                existingTestimonial.UpdatedAt = DateTime.Now;
                _context.SaveChanges();
                return Ok("Testimonial deleted successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //----------------------------GET----------------------------
        //-----------------------------------------------------------

        [HttpGet]
        public IActionResult GetTestimonials()
        {
            try
            {
                var testimonials = _context.Testimonials
                    .Where(t => t.IsDeleted == false)
                    .Select(t => new TestimonialDTO
                    {
                        TestimonialId = t.TestimonialId,
                        ClientId = t.ClientId,
                        photoUrl = t.Client.PhotoUrl,
                        clientName = t.Client.ClientName,
                        TestimonialText = t.TestimonialText,
                        AuthorName = t.AuthorName,
                        IsDeleted = t.IsDeleted,
                        CreatedAt = t.CreatedAt,
                        UpdatedAt = t.UpdatedAt
                    })
                    .ToList();
                return Ok(testimonials);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //------------------------------------------------------------
        //------------------------GET BY ID---------------------------
        //------------------------------------------------------------

        [HttpGet("GetTestimonialById")]
        public IActionResult GetTestimonialById(int id)
        {
            try
            {
                var testimonial = _context.Testimonials
                    .Where(t => t.TestimonialId == id && t.IsDeleted == false)
                    .Select(t => new TestimonialDTO
                    {
                        TestimonialId = t.TestimonialId,
                        ClientId = t.ClientId,
                        photoUrl = t.Client.PhotoUrl,
                        clientName = t.Client.ClientName,
                        TestimonialText = t.TestimonialText,
                        AuthorName = t.AuthorName,
                        IsDeleted = t.IsDeleted,
                        CreatedAt = t.CreatedAt,
                        UpdatedAt = t.UpdatedAt
                    }).FirstOrDefault();

                if (testimonial == null)
                {
                    return NotFound("Testimonial not found");
                }
                return Ok(testimonial);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }



        }
}
