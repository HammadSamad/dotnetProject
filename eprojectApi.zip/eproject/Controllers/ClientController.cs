﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientController : ControllerBase
    {

        private readonly StarSecuritiesContext _context;
        private readonly IConfiguration _config;

        public ClientController(StarSecuritiesContext context,IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        //----------------------------------------------------------------
        //------------------------ POST ----------------------------------
        //----------------------------------------------------------------

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddClient(ClientCreate client)
        {
            try {
                if (client != null && client.PhotoUrl != null)
                {
                    var uploadPath = _config["StoredFilesPath"];

                    if (!Directory.Exists(uploadPath))
                        Directory.CreateDirectory(uploadPath);

                    var extention = Path.GetExtension(client.PhotoUrl.FileName);
                    var imageName = Guid.NewGuid().ToString() + extention;
                    var filePath = Path.Combine(uploadPath, imageName);
                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await client.PhotoUrl.CopyToAsync(stream);
                    }

                    var clients = new Client
                    {
                        ClientName = client.ClientName,
                        ClientEmail = client.ClientEmail,
                        PhotoUrl = imageName,
                        ClientNumber = client.ClientNumber,
                        ClientAddress = client.ClientAddress,
                        IsDeleted = false,
                        CreatedAt = DateTime.Now,
                        UpdatedAt = DateTime.Now
                    };

                    _context.Clients.Add(clients);
                    _context.SaveChanges();

                }
                return Ok("Client added successfully");

            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }

        }

        //----------------------------------------------------------------
        //------------------------ PUT -----------------------------------
        //----------------------------------------------------------------

        [HttpPut]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateClient(ClientCreate Client,int id)
        {
            try
            {
                var editClient = await _context.Clients.FindAsync(id);
                if (editClient == null)
                    return NotFound("Client not found");

                // update non-image fields
                editClient.ClientName = Client.ClientName;
                editClient.ClientEmail = Client.ClientEmail;
                editClient.ClientNumber = Client.ClientNumber;
                editClient.ClientAddress = Client.ClientAddress;
                editClient.UpdatedAt = DateTime.Now;

                // Only update image if a new one is uploaded
                if (Client.PhotoUrl != null && Client.PhotoUrl.Length > 0)
                {
                    var uploadPath = _config["StoredFilesPath"];
                    if (!Directory.Exists(uploadPath))
                        Directory.CreateDirectory(uploadPath);

                    var extension = Path.GetExtension(Client.PhotoUrl.FileName);
                    var imageName = Guid.NewGuid().ToString() + extension;
                    var filePath = Path.Combine(uploadPath, imageName);

                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await Client.PhotoUrl.CopyToAsync(stream);
                    }

                    // Optional: delete old image if it exists
                    if (!string.IsNullOrEmpty(editClient.PhotoUrl))
                    {
                        var oldImagePath = Path.Combine(uploadPath, editClient.PhotoUrl);
                        if (System.IO.File.Exists(oldImagePath))
                        {
                            System.IO.File.Delete(oldImagePath);
                        }
                    }

                    // Assign the new image
                    editClient.PhotoUrl = imageName;
                }

                _context.Clients.Update(editClient);
                await _context.SaveChangesAsync();

                return Ok("Client updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }

        }

        //----------------------------------------------------------------
        //------------------------ DELETE --------------------------------
        //----------------------------------------------------------------

        [HttpDelete]
        [Authorize(Roles = "Admin")]
        public IActionResult DeleteClient(int id)
        {
            try
            {
                var client = _context.Clients.Find(id);
                if (client == null)
                    return NotFound("Client not found");

                client.IsDeleted = true;
                client.UpdatedAt = DateTime.Now;
                _context.SaveChanges();

                return Ok("Client deleted successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ GET -----------------------------------
        //----------------------------------------------------------------

        [HttpGet]
        public IActionResult GetClients()
        {
            try
            {
                var clients = _context.Clients.Where(c => c.IsDeleted == false).Select(c => new ClientDTO
                {
                    ClientId = c.ClientId,
                    ClientName = c.ClientName,
                    ClientEmail = c.ClientEmail,
                    PhotoUrl = c.PhotoUrl,
                    ClientNumber = c.ClientNumber,
                    ClientAddress = c.ClientAddress,
                    IsDeleted = c.IsDeleted,
                    CreatedAt = c.CreatedAt,
                    UpdatedAt = c.UpdatedAt
                }).ToList();
                if (clients.Count > 0)
                {
                    return Ok(clients);
                }
                return NotFound("Client not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------ GET Client By Id ---------------------------
        //----------------------------------------------------------------

        [HttpGet("GetClientById")]
        public IActionResult GetClientById(int id)
        {
            try
            {
                var data = _context.Clients.Where(c => c.ClientId == id && c.IsDeleted == false).Select(c => new ClientDTO
                {
                    ClientId = c.ClientId,
                    ClientName = c.ClientName,
                    ClientEmail = c.ClientEmail,
                    PhotoUrl = c.PhotoUrl,
                    ClientNumber = c.ClientNumber,
                    ClientAddress = c.ClientAddress,
                    IsDeleted = c.IsDeleted,
                    CreatedAt = c.CreatedAt,
                    UpdatedAt = c.UpdatedAt
                }).FirstOrDefault();
                    return Ok(data);

            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


    }
}
