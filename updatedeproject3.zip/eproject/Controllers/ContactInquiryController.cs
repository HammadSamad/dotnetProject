﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactInquiryController : ControllerBase
    {

        private readonly StarSecuritiesContext _context;

        public ContactInquiryController(StarSecuritiesContext context)
        {
            _context = context;
        }

        //----------------------------------------------------------------
        //------------------------ POST ----------------------------------
        //----------------------------------------------------------------

        [HttpPost]
        public IActionResult AddContactInquiry(ContactInquiry contactInquiry)
        {
            try
            {
                if (contactInquiry != null)
                {
                    var contactInquiries = _context.ContactInquiries.Add(contactInquiry);
                    _context.SaveChanges();
                }
                return Ok("Contact Inquiry added successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ PUT -----------------------------------
        //----------------------------------------------------------------

        [HttpPut]
        public IActionResult UpdateContactInquiry(ContactInquiry contactInquiry, int id)
        {
            try
            {
                var editContactInquiry = _context.ContactInquiries.Find(id);
                if (editContactInquiry != null)
                {
                    editContactInquiry.Name = contactInquiry.Name;
                    editContactInquiry.Email = contactInquiry.Email;
                    editContactInquiry.Phone = contactInquiry.Phone;
                    editContactInquiry.Message = contactInquiry.Message;
                    editContactInquiry.UpdatedAt = DateTime.Now;
                }
                _context.SaveChanges();
                return Ok("Contact Inquiry updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ DELETE --------------------------------
        //----------------------------------------------------------------

        [HttpDelete]
        public IActionResult DeleteContactInquiry(int id)
        {
            try
            {
                var deleteContactInquiry = _context.ContactInquiries.Find(id);
                if (deleteContactInquiry != null)
                {
                    _context.ContactInquiries.Remove(deleteContactInquiry);
                    _context.SaveChanges();
                    return Ok("Contact Inquiry deleted successfully");
                }
                return NotFound("Contact Inquiry not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ GET -----------------------------------
        //----------------------------------------------------------------

        [HttpGet]
        public IActionResult GetAllContactInquiries()
        {
            try
            {
                var contactInquiries = _context.ContactInquiries.ToList();
                if(contactInquiries != null)
                { 
                return Ok(contactInquiries);
                }
                return NotFound("No Contact Inquiries found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ GET BY ID -----------------------------
        //----------------------------------------------------------------

        [HttpGet("GetCIById")]
        public IActionResult GetContactInquiryById(int id)
        {
            try
            {
                var contactInquiry = _context.ContactInquiries.Where(ci => ci.InquiryId == id).FirstOrDefault();
                if (contactInquiry != null)
                {
                    return Ok(contactInquiry);
                }
                return NotFound("Contact Inquiry not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }




    }
}
