﻿using eproject.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IdentityModel.Tokens.Jwt;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeLoginController : ControllerBase
    {

        private readonly StarSecuritiesContext _context;
        private readonly JwtSecurityToken _jwt;

        public EmployeeLoginController(StarSecuritiesContext context, JwtSecurityToken jwt)
        {
            _context = context;
            _jwt = jwt;
        }



    }
}
