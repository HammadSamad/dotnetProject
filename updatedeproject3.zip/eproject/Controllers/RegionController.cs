﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegionController : ControllerBase
    {

        private readonly StarSecuritiesContext _context;

        public RegionController(StarSecuritiesContext context)
        {
            _context = context;
        }

        //----------------------------------------------------------
        //----------------------- POST -----------------------------
        //----------------------------------------------------------

        [HttpPost]
        public IActionResult AddRegion(RegionCreate region)
        {
            try
            {
                if (region != null)
                {
                    var regions = new Region
                    {
                        RegionName = region.RegionName,
                        BranchId = region.BranchId,
                        CreatedAt = DateTime.Now,
                        UpdatedAt = DateTime.Now
                    };

                    _context.SaveChanges();
                    return Ok("Region added successfully");
                }
                return BadRequest("Region added failed");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------
        //------------------------ PUT -----------------------------
        //----------------------------------------------------------

        [HttpPut]
        public IActionResult UpdateRegion(RegionCreate region, int id)
        {
            try
            {
                var editRegion = _context.Regions.Find(id);
                if (editRegion != null)
                {
                    editRegion.RegionName = region.RegionName;
                    editRegion.BranchId = region.BranchId;
                    editRegion.UpdatedAt = DateTime.Now;
                    _context.SaveChanges();
                    return Ok("Region updated successfully");
                }
                return NotFound("Region not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //------------------------- DELETE --------------------------
        //-----------------------------------------------------------

        [HttpDelete]
        public IActionResult DeleteRegion(int id)
        {
            try
            {
                var deleteRegion = _context.Regions.Find(id);
                if (deleteRegion != null)
                {
                    _context.Regions.Remove(deleteRegion);
                    _context.SaveChanges();
                    return Ok("Region deleted successfully");
                }
                return NotFound("Region not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //--------------------GET REGION-----------------------------
        //-----------------------------------------------------------

        [HttpGet]
        public IActionResult GetRegion()
        {
            try
            {
                var regions = _context.Regions.ToList();
                if (regions != null && regions.Count > 0)
                {
                    return Ok(regions);
                }
                return NotFound("Region not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //---------------------------------------------------------
        //------------GET REGION BY ID-----------------------------
        //---------------------------------------------------------

        [HttpGet("GetRById")]
        public IActionResult GetRegionById(int id)
        {
            try { 
            var regions = _context.Regions.Where(r => r.RegionId == id).FirstOrDefault();
                if (regions == null)
                {
                    return NotFound("Region not found");
                }
                return Ok(regions);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------
        //-------------GET REGION WITH BRANCH------------------
        //-----------------------------------------------------

        [HttpGet("GetRigonBranch")]
        public IActionResult GetRegionsWithBranch()
        {
            try
            {
                var regions = _context.Regions.Include(r => r.Branch).Select(r => new RegionDTO
                {
                    RegionId = r.RegionId,
                    RegionName = r.RegionName,
                    BranchId = r.BranchId,
                    BranchName = r.Branch.BranchName
                });
                return Ok(regions);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------
        //----------GET REGION WITH BRANCH BY ID---------------
        //-----------------------------------------------------

        [HttpGet("GetRigonBranchById")]
        public IActionResult GetRegionBranchById(int id)
        {
            try
            {
                var region = _context.Regions.Where(r => r.RegionId == id).Include(r => r.Branch).Select(r => new RegionDTO
                {
                    RegionId = r.RegionId,
                    RegionName = r.RegionName,
                    BranchId = r.BranchId,
                    BranchName = r.Branch.BranchName
                }).FirstOrDefault();
                if (region != null)
                {
                    return Ok(region);
                }
                return NotFound("Region not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }



    }
}
