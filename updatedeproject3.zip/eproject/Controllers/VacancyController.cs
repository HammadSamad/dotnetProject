﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VacancyController : ControllerBase
    {

        private readonly StarSecuritiesContext _context;

        public VacancyController(StarSecuritiesContext context)
        {
            _context = context;
        }

        //-----------------------------------------------------------
        //----------------------- POST ------------------------------
        //-----------------------------------------------------------

        [HttpPost]
        public IActionResult AddVacancy(VacancyCreate vacancy)
        {
            try
            {
                if (vacancy != null)
                {
                    var vacancies = new Vacancy
                    {
                        Title = vacancy.Title,
                        Description = vacancy.Description,
                        DepartmentId = vacancy.DepartmentId,
                        Status = vacancy.Status,
                        IsDeleted = false,
                        CreatedAt = DateTime.Now,
                        UpdatedAt = DateTime.Now
                    };
                }
                return Ok("Vacancy added successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //------------------------- PUT -----------------------------
        //-----------------------------------------------------------

        [HttpPut]
        public IActionResult UpdateVacancy(VacancyCreate vacancy, int id)
        {
            try
            {
                var existingVacancy = _context.Vacancies.Find(id);
                if (existingVacancy == null)
                {
                    return NotFound("Vacancy not found");
                }
                existingVacancy.Title = vacancy.Title;
                existingVacancy.Description = vacancy.Description;
                existingVacancy.DepartmentId = vacancy.DepartmentId;
                existingVacancy.Status = vacancy.Status;
                existingVacancy.UpdatedAt = DateTime.Now;
                _context.Vacancies.Update(existingVacancy);
                _context.SaveChanges();
                return Ok("Vacancy updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //------------------------- DELETE --------------------------
        //-----------------------------------------------------------

        [HttpDelete]
        public IActionResult DeleteVacancy(int id)
        {
            try
            {
                var existingVacancy = _context.Vacancies.Find(id);
                if (existingVacancy == null)
                {
                    return NotFound("Vacancy not found");
                }
                existingVacancy.IsDeleted = true;
                existingVacancy.UpdatedAt = DateTime.Now;
                _context.Vacancies.Update(existingVacancy);
                _context.SaveChanges();
                return Ok("Vacancy deleted successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //------------------------- GET -----------------------------
        //-----------------------------------------------------------

        [HttpGet]
        public IActionResult GetAllVacancies()
        {
            try
            {
                var vacancies = _context.Vacancies.Include(v => v.Department).Where(v => v.IsDeleted == false).Select(v => new VacancyDTO
                {
                    VacancyId = v.VacancyId,
                    Title = v.Title,
                    Description = v.Description,
                    DepartmentId = v.DepartmentId,
                    DepartmentName = v.Department.DepartmentName,
                    Status = v.Status,
                    IsDeleted = v.IsDeleted,
                    CreatedAt = v.CreatedAt,
                    UpdatedAt = v.UpdatedAt
                }).ToList();
                return Ok(vacancies);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //----------------------- GET BY ID -------------------------
        //-----------------------------------------------------------

        [HttpGet("GetVById")]
        public IActionResult GetVacancyById(int id)
        {
            try
            {
                var vacancy = _context.Vacancies.Include(v => v.Department).Where(v => v.IsDeleted == false && v.VacancyId == id).Select(v => new VacancyDTO
                {
                    VacancyId = v.VacancyId,
                    Title = v.Title,
                    Description = v.Description,
                    DepartmentId = v.DepartmentId,
                    DepartmentName = v.Department.DepartmentName,
                    Status = v.Status,
                    IsDeleted = v.IsDeleted,
                    CreatedAt = v.CreatedAt,
                    UpdatedAt = v.UpdatedAt
                }).FirstOrDefault();
                if (vacancy == null)
                {
                    return NotFound("Vacancy not found");
                }
                return Ok(vacancy);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }



       }
}
