﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {

        private readonly StarSecuritiesContext _context;

        public EmployeeController(StarSecuritiesContext context)
        {
            _context = context;
        }

        //-------------------------------------------------------------
        //---------------------------- POST ---------------------------
        //-------------------------------------------------------------

        [HttpPost]
        public IActionResult AddEmployee(EmployeeCreate employee)
        {
            try
            {
                if (employee != null)
                {
                    var newEmployee = new Employee
                    {
                        EmployeeCode = employee.EmployeeCode,
                        EmployeeName = employee.EmployeeName,
                        Address = employee.Address,
                        ContactNumber = employee.ContactNumber,
                        EducationalQualification = employee.EducationalQualification,
                        DepartmentId = employee.DepartmentId,
                        RoleId = employee.RoleId,
                        GradeId = employee.GradeId,
                        Achievements = employee.Achievements,
                        IsDeleted = false,
                        CreatedAt = DateTime.Now,
                        UpdatedAt = DateTime.Now
                    };
                    _context.Employees.Add(newEmployee);
                    _context.SaveChanges();
                }
                    return Ok("Employee added successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-------------------------------------------------------------
        //---------------------------- PUT ----------------------------
        //-------------------------------------------------------------

        [HttpPut]
        public IActionResult UpdateEmployee(EmployeeCreate employee)
        {
            try
            {
                var existingEmployee = _context.Employees.Find(employee.EmployeeId);
                if (existingEmployee != null)
                {
                    existingEmployee.EmployeeCode = employee.EmployeeCode;
                    existingEmployee.EmployeeName = employee.EmployeeName;
                    existingEmployee.Address = employee.Address;
                    existingEmployee.ContactNumber = employee.ContactNumber;
                    existingEmployee.EducationalQualification = employee.EducationalQualification;
                    existingEmployee.DepartmentId = employee.DepartmentId;
                    existingEmployee.RoleId = employee.RoleId;
                    existingEmployee.GradeId = employee.GradeId;
                    existingEmployee.Achievements = employee.Achievements;
                    existingEmployee.UpdatedAt = DateTime.Now;
                    _context.SaveChanges();
                    return Ok("Employee updated successfully");
                }
                return NotFound("Employee not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-------------------------------------------------------------
        //--------------------------- DELETE --------------------------
        //-------------------------------------------------------------

        [HttpDelete]
        public IActionResult DeleteEmployee(int employeeId)
        {
            try
            {
                var existingEmployee = _context.Employees.Find(employeeId);
                if (existingEmployee != null)
                {
                    existingEmployee.IsDeleted = true;
                    existingEmployee.UpdatedAt = DateTime.Now;
                    _context.SaveChanges();
                    return Ok("Employee deleted successfully");
                }
                return NotFound("Employee not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

            //-------------------------------------------------------------
            //---------------------------- GET ----------------------------
            //-------------------------------------------------------------

            [HttpGet]
            public IActionResult GetEmployees()
            {
                try
                {
                    var employees = _context.Employees.Include(e => e.Department).Include(e => e.Role).Include(e => e.Grade).Where(e => e.IsDeleted == false).Select(e => new EmployeeDTO
                    {
                        EmployeeId = e.EmployeeId,
                        EmployeeCode = e.EmployeeCode,
                        EmployeeName = e.EmployeeName,
                        Address = e.Address,
                        ContactNumber = e.ContactNumber,
                        EducationalQualification = e.EducationalQualification,
                        DepartmentId = e.DepartmentId,
                        DepartmentName = e.Department.DepartmentName,
                        RoleId = e.RoleId,
                        RoleName = e.Role.RoleName,
                        GradeId = e.GradeId,
                        GradeName = e.Grade.GradeName,
                        Achievements = e.Achievements,
                        IsDeleted = e.IsDeleted,
                        CreatedAt = e.CreatedAt,
                        UpdatedAt = e.UpdatedAt
                    });
                    return Ok(employees);
                }
                catch (Exception error)
                {
                    return BadRequest(error.Message);
                }
            }

        //-------------------------------------------------------------
        //------------------------- GET BY ID -------------------------
        //-------------------------------------------------------------

        [HttpGet("GetEById")]
        public IActionResult GetEmployeeById(int id)
        {
            try
            {
                var employee = _context.Employees.Include(e => e.Department).Include(e => e.Role).Include(e => e.Grade).Where(e => e.EmployeeId == id && e.IsDeleted == false).Select(e => new EmployeeDTO
                {
                    EmployeeId = e.EmployeeId,
                    EmployeeCode = e.EmployeeCode,
                    EmployeeName = e.EmployeeName,
                    Address = e.Address,
                    ContactNumber = e.ContactNumber,
                    EducationalQualification = e.EducationalQualification,
                    DepartmentId = e.DepartmentId,
                    DepartmentName = e.Department.DepartmentName,
                    RoleId = e.RoleId,
                    RoleName = e.Role.RoleName,
                    GradeId = e.GradeId,
                    GradeName = e.Grade.GradeName,
                    Achievements = e.Achievements,
                    IsDeleted = e.IsDeleted,
                    CreatedAt = e.CreatedAt,
                    UpdatedAt = e.UpdatedAt
                }).FirstOrDefault();
                if (employee != null)
                {
                    return Ok(employee);
                }
                return NotFound("Employee not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


        }
    }
