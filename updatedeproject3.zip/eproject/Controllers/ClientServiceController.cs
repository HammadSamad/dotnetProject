﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientServiceController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;

        public ClientServiceController(StarSecuritiesContext context)
        {
            _context = context;
        }

        //----------------------------------------------------------------
        //------------------------ POST ----------------------------------
        //----------------------------------------------------------------

        [HttpPost]
        public IActionResult AddClientService(ClientServiceCreate clientService)
        {
            try
            {
                if (clientService == null)
                {
                    return BadRequest("Invalid request");
                }

                // Find client in Clients table
                var client = _context.Clients.FirstOrDefault(c => c.ClientId == clientService.ClientId);

                if (client == null)
                {
                    return NotFound("Client not found");
                }

                if (client.IsDeleted == true)
                {
                    return BadRequest("Cannot add service to a deleted client.");
                }

                // Only add if client is valid and active
                var newClientService = new ClientService
                {
                    ClientId = clientService.ClientId,
                    ServiceId = clientService.ServiceId,
                    IsDeleted = false,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                _context.ClientServices.Add(newClientService);
                _context.SaveChanges();

                return Ok("Client Service Added Successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


        //----------------------------------------------------------------
        //------------------------ PUT -----------------------------------
        //----------------------------------------------------------------

        [HttpPut]
        public IActionResult UpdateClientService(ClientServiceCreate updateClientService, int id)
        {
            try
            {
                var editClientService = _context.ClientServices.Find(id);

                if (editClientService == null)
                {
                    return NotFound("Client Service not found");
                }

                // Check if the new client exists
                var client = _context.Clients.FirstOrDefault(c => c.ClientId == updateClientService.ClientId);
                if (client == null)
                {
                    return NotFound("Client not found");
                }

                // Block if client is deleted
                if (client.IsDeleted == true)
                {
                    return BadRequest("Cannot assign a deleted client to this service.");
                }

                // Update only if valid
                editClientService.ClientId = updateClientService.ClientId;
                editClientService.ServiceId = updateClientService.ServiceId;
                editClientService.UpdatedAt = DateTime.Now;

                _context.SaveChanges();

                return Ok("Client Service updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


        //----------------------------------------------------------------
        //------------------------ DELETE --------------------------------
        //----------------------------------------------------------------

        [HttpDelete]
        public IActionResult DeleteClientService(int id)
        {
            try
            {
                var deleteClientService = _context.ClientServices.Find(id);
                if (deleteClientService != null)
                {
                    deleteClientService.IsDeleted = true;
                    deleteClientService.UpdatedAt = DateTime.Now;
                }
                _context.SaveChanges();
                return Ok("Client Service deleted successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ GET -----------------------------------
        //----------------------------------------------------------------

        [HttpGet]
        public IActionResult GetClientServices()
        {
            try
            {
                var clientData = _context.ClientServices
                    .Include(cd => cd.Client)
                    .Include(cd => cd.Service)
                    .Where(cd => cd.IsDeleted == false
                              && cd.Client.IsDeleted == false
                              && cd.Service.IsDeleted == false)
                    .Select(cd => new ClientServiceDTO
                    {
                        ClientServiceId = cd.ClientServiceId,
                        ClientId = cd.ClientId,
                        ClientName = cd.Client.ClientName,
                        ServiceId = cd.ServiceId,
                        ServiceName = cd.Service.ServiceName,
                        IsDeleted = cd.IsDeleted,
                        CreatedAt = cd.CreatedAt,
                        UpdatedAt = cd.UpdatedAt
                    })
                    .ToList();

                return Ok(clientData);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


        //----------------------------------------------------------------
        //------------------------ GET BY ID -----------------------------
        //----------------------------------------------------------------

        [HttpGet("GetCSById")]
        public IActionResult GetClientServiceById(int id)
        {
            try
            {
                var clientService = _context.ClientServices
                    .Include(cd => cd.Client)
                    .Include(cd => cd.Service)
                    .Where(cs => cs.ClientServiceId == id
                              && cs.IsDeleted == false
                              && cs.Client.IsDeleted == false
                              && cs.Service.IsDeleted == false)
                    .Select(cs => new ClientServiceDTO
                    {
                        ClientServiceId = cs.ClientServiceId,
                        ClientId = cs.ClientId,
                        ClientName = cs.Client.ClientName,
                        ServiceId = cs.ServiceId,
                        ServiceName = cs.Service.ServiceName,
                        IsDeleted = cs.IsDeleted,
                        CreatedAt = cs.CreatedAt,
                        UpdatedAt = cs.UpdatedAt
                    })
                    .FirstOrDefault();

                if (clientService != null)
                {
                    return Ok(clientService);
                }

                return NotFound("Client Service not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }




    }
}
