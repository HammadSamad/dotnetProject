﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanyHistoryController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;
        private readonly IConfiguration _config;

        public CompanyHistoryController(StarSecuritiesContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        //----------------------------------------------------------------------
        //---------POST Create Company History with image upload--------------
        //----------------------------------------------------------------------

        [HttpPost]
        public async Task<IActionResult> AddCompanyHistory(CompanyHistoryCreate companyHistory)
        {
            try
            {
                if (companyHistory != null && companyHistory.PhotoUrl != null)
                {
                    var uploadPath = _config["StoredFilesPath"];

                    if (!Directory.Exists(uploadPath))
                        Directory.CreateDirectory(uploadPath);

                    var extention = Path.GetExtension(companyHistory.PhotoUrl.FileName);
                    var imageName = Guid.NewGuid().ToString() + extention;
                    var filePath = Path.Combine(uploadPath, imageName);
                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await companyHistory.PhotoUrl.CopyToAsync(stream);
                    }

                    var companyHistoryData = new CompanyHistory
                    {
                        FoundedDate = companyHistory.FoundedDate,
                        HistoryDescription = companyHistory.HistoryDescription,
                        Location = companyHistory.Location,
                        PhotoUrl = imageName,
                        CreatedAt = DateTime.Now,
                        UpdatedAt = DateTime.Now
                    };

                    _context.CompanyHistories.Add(companyHistoryData);
                    _context.SaveChanges();
                }
                    return Ok("Company History added successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ PUT -----------------------------------
        //----------------------------------------------------------------

        [HttpPut]
        public async Task<IActionResult> UpdateCompanyHistory(CompanyHistoryCreate companyHistory, int id)
        {
            try
            {
                var editCompanyHistory = await _context.CompanyHistories.FindAsync(id);
                if (editCompanyHistory == null)
                    return NotFound("Company History not found");

                // Always update non-image fields
                editCompanyHistory.FoundedDate = companyHistory.FoundedDate;
                editCompanyHistory.HistoryDescription = companyHistory.HistoryDescription;
                editCompanyHistory.Location = companyHistory.Location;
                editCompanyHistory.UpdatedAt = DateTime.Now;

                // Only update image if a new one is uploaded
                if (companyHistory.PhotoUrl != null && companyHistory.PhotoUrl.Length > 0)
                {
                    var uploadPath = _config["StoredFilesPath"];
                    if (!Directory.Exists(uploadPath))
                        Directory.CreateDirectory(uploadPath);

                    var extension = Path.GetExtension(companyHistory.PhotoUrl.FileName);
                    var imageName = Guid.NewGuid().ToString() + extension;
                    var filePath = Path.Combine(uploadPath, imageName);

                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await companyHistory.PhotoUrl.CopyToAsync(stream);
                    }

                    // Optional: delete old image if it exists
                    if (!string.IsNullOrEmpty(editCompanyHistory.PhotoUrl))
                    {
                        var oldImagePath = Path.Combine(uploadPath, editCompanyHistory.PhotoUrl);
                        if (System.IO.File.Exists(oldImagePath))
                        {
                            System.IO.File.Delete(oldImagePath);
                        }
                    }

                    // Assign the new image
                    editCompanyHistory.PhotoUrl = imageName;
                }

                _context.CompanyHistories.Update(editCompanyHistory);
                await _context.SaveChangesAsync();

                return Ok("Board of Director updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ DELETE --------------------------------
        //----------------------------------------------------------------

        [HttpDelete]
        public IActionResult DelBoardOfDirector(int id)
        {
            try
            {
                var delboardOfDirector = _context.BoardOfDirectors.Find(id);
                if (delboardOfDirector != null)
                {
                    _context.BoardOfDirectors.Remove(delboardOfDirector);
                    _context.SaveChanges();
                    return Ok("Company History deleted successfully");
                }
                return StatusCode(204);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ GET -----------------------------------
        //----------------------------------------------------------------

        [HttpGet]
        public IActionResult GetCompanyHistory()
        {
            try
            {
                var companyHistory = _context.CompanyHistories.ToList();
                if (companyHistory != null && companyHistory.Count > 0)
                {
                    return Ok(companyHistory);
                }
                return StatusCode(204);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }

        }

        //----------------------------------------------------------------
        //------------------------ GET BY ID ------------------------------
        //----------------------------------------------------------------

        [HttpGet("GetCHById")]
        public IActionResult GetCompanyHistoryById(int id)
        {
            try
            {
                var data = _context.CompanyHistories.Where(ch => ch.HistoryId == id).Select(ch => new CompanyHistoryDTO
                {
                    HistoryId = ch.HistoryId,
                    FoundedDate = ch.FoundedDate,
                    HistoryDescription = ch.HistoryDescription,
                    Location = ch.Location,
                    PhotoUrl = ch.PhotoUrl,
                    CreatedAt = ch.CreatedAt,
                    UpdatedAt = ch.UpdatedAt
                }).FirstOrDefault();
                return Ok(data);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


    }
}
