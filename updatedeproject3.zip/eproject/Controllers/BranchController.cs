﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BranchController : ControllerBase
    {

        private readonly StarSecuritiesContext _context;

        public BranchController(StarSecuritiesContext context)
        {
            _context = context;
        }

        //----------------------------------------------------------------
        //------------------------ POST ----------------------------------
        //---------------------------------------------------------------

        [HttpPost]
        public IActionResult AddBranch(Branch branch)
        {
            try
            {
                if (branch != null)
                {
                    _context.Branches.Add(branch);
                    _context.SaveChanges();
                    return Ok("Branch added successfully");
                }
                return BadRequest("Branch added failed");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ PUT -----------------------------------
        //----------------------------------------------------------------

        [HttpPut]
        public IActionResult UpdateBranch(Branch branch,int id)
        {
            try
            {
                var editBranch = _context.Branches.Find(id);
                if (editBranch != null)
                {
                    editBranch.BranchName = branch.BranchName;
                    editBranch.Address = branch.Address;
                    editBranch.ContactNumber = branch.ContactNumber;
                    editBranch.Email = branch.Email;
                    editBranch.UpdatedAt = DateTime.Now;
                    _context.SaveChanges();
                    return Ok("Branch updated successfully");
                }
                return NotFound("Branch not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ DELETE --------------------------------
        //----------------------------------------------------------------

        [HttpDelete]
        public IActionResult DeleteBranch(int id)
        {
            try
            {
                var branch = _context.Branches.Find(id);
                if (branch != null)
                {
                    _context.Branches.Remove(branch);
                    _context.SaveChanges();
                    return Ok("Branch deleted successfully");
                }
                return NotFound("Branch not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //---------------------- GET ALL bRANCHES ------------------------
        //----------------------------------------------------------------

        [HttpGet]
        public IActionResult GetAllBranches()
        {
            try
            {
                var branches = _context.Branches.ToList();
                if (branches != null && branches.Count > 0)
                {
                    return Ok(branches);
                }
                return NotFound("No branches found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //---------------------- GET BRANCH BY ID ------------------------
        //----------------------------------------------------------------

        [HttpGet("GetBById")]
        public IActionResult GetBranchById(int id)
        {
            try
            {
                var branch = _context.Branches.Find(id);
                if (branch != null)
                {
                    return Ok(branch);
                }
                return NotFound("Branch not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


    }
}
