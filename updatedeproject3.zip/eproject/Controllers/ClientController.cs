﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientController : ControllerBase
    {

        private readonly StarSecuritiesContext _context;

        public ClientController(StarSecuritiesContext context)
        {
            _context = context;
        }

        //----------------------------------------------------------------
        //------------------------ POST ----------------------------------
        //----------------------------------------------------------------

        [HttpPost]
        public IActionResult AddClient(Client client)
        {
            try { 
                if (client != null)
                {
                    var clients = _context.Clients.Add(client);
                    _context.SaveChanges();
                }
                    return Ok("Client added successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }

        }

        //----------------------------------------------------------------
        //------------------------ PUT -----------------------------------
        //----------------------------------------------------------------

        [HttpPut]
        public IActionResult UpdateClient(Client Client,int id)
        {
            try
            {
                var editClient = _context.Clients.Find(id);
                if (editClient != null)
                {
                    editClient.ClientName = Client.ClientName;
                    editClient.UpdatedAt = DateTime.Now;
                } 
                _context.SaveChanges();
                return Ok("Client updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }

        }

        //----------------------------------------------------------------
        //------------------------ DELETE --------------------------------
        //----------------------------------------------------------------

        [HttpDelete]
        public IActionResult DeleteClient(int id)
        {
            try
            {
                var client = _context.Clients.Find(id);
                if (client == null)
                    return NotFound("Client not found");

                client.IsDeleted = true;
                client.UpdatedAt = DateTime.Now;
                _context.SaveChanges();

                return Ok("Client deleted successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ GET -----------------------------------
        //----------------------------------------------------------------

        [HttpGet]
        public IActionResult GetClients()
        {
            try
            {
                var clients = _context.Clients.Where(c => c.IsDeleted == false).ToList();
                if (clients.Count > 0)
                {
                    return Ok(clients);
                }
                return NotFound("Client not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------ GET Client By Id ---------------------------
        //----------------------------------------------------------------

        [HttpGet("GetClientById")]
        public IActionResult GetClientById(int id)
        {
            try
            {
                var data = _context.Clients.Where(c => c.ClientId == id && c.IsDeleted == false).Select(c => new Client
                {
                    ClientId = c.ClientId,
                    ClientName = c.ClientName,
                    IsDeleted = c.IsDeleted,
                    CreatedAt = c.CreatedAt,
                    UpdatedAt = c.UpdatedAt
                }).FirstOrDefault();
                    return Ok(data);

            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


    }
}
