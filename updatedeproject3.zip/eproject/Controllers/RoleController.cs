﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;

        public RoleController(StarSecuritiesContext context)
        {
            _context = context;
        }

        //----------------------------------------------------------------
        //------------------------ POST ----------------------------------
        //----------------------------------------------------------------

        [HttpPost]
        public IActionResult AddRole(Role role)
        {
            try
            {
                if (role != null)
                {
                    _context.Roles.Add(role);
                    _context.SaveChanges();
                    return Ok("Role added successfully");
                }
                return Ok("Role added failed");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ PUT -----------------------------------
        //----------------------------------------------------------------

        [HttpPut]
        public IActionResult UpdateRole(Role role, int id)
        {
            try
            {
                var editRole = _context.Roles.Find(id);
                if (editRole != null)
                {
                    editRole.RoleName = role.RoleName;
                    _context.SaveChanges();
                    return Ok("Role updated successfully");
                }
                return NotFound("Role not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ DELETE --------------------------------
        //----------------------------------------------------------------

        [HttpDelete]
        public IActionResult RoleGetById(int id)
        {
            try
            {
                var role = _context.Roles.Find(id);
                if (role != null)
                {
                    _context.Roles.Remove(role);
                    _context.SaveChanges();
                    return Ok("Role deleted successfully");
                }
                return NotFound("Role not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ GET -----------------------------------
        //----------------------------------------------------------------

        [HttpGet]
        public IActionResult GetRoles()
        {
            try
            {
                var roles = _context.Roles.ToList();
                if (roles.Count > 0)
                {
                    return Ok(roles);
                }
                return NotFound("No roles found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ GET BY ID -----------------------------
        //----------------------------------------------------------------

        [HttpGet("RoleGetById")]
        public IActionResult GetRoleById(int id)
        {
            try
            {
                var role = _context.Roles.Where(r => r.RoleId == id).FirstOrDefault();
                if (role != null)
                {
                    return Ok(role);
                }
                return NotFound("Role not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


    }
}
