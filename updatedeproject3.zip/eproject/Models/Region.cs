﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace eproject.Models;

public partial class Region
{
    public int RegionId { get; set; }

    public string RegionName { get; set; } = null!;

    public int BranchId { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    [JsonIgnore]
    public virtual Branch Branch { get; set; } = null!;
}
