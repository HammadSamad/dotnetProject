﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace eproject.Models;

public partial class Vacancy
{
    public int VacancyId { get; set; }

    public string Title { get; set; } = null!;

    public int DepartmentId { get; set; }

    public string Description { get; set; } = null!;

    public string Status { get; set; } = null!;

    public bool? IsDeleted { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    [JsonIgnore]
    public virtual Department Department { get; set; } = null!;
}
