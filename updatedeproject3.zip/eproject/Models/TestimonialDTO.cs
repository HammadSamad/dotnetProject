﻿using System.Text.Json.Serialization;

namespace eproject.Models
{
    public class TestimonialDTO
    {
        public int TestimonialId { get; set; }

        public int ClientId { get; set; }

        public string? clientName { get; set; }

        public string TestimonialText { get; set; } = null!;

        public string AuthorName { get; set; } = null!;

        public bool? IsDeleted { get; set; }

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }
}
