﻿using System.Text.Json.Serialization;

namespace eproject.Models
{
    public class ClientServiceCreate
    {
        public int ClientServiceId { get; set; }

        public int ClientId { get; set; }

        public int ServiceId { get; set; }

        public bool? IsDeleted { get; set; }

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }
}
