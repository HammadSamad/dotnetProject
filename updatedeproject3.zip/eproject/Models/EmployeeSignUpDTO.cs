﻿namespace eproject.Models
{
    public class EmployeeSignUpDTO
    {
        public string username { get; set; } = null!;

        public string passwordHash { get; set; } = null!;

        public List<string> RoleName { get; set; } = null!;

    }
}
