﻿namespace eproject.Models
{
    public class EmployeeDTO
    {
        public int EmployeeId { get; set; }

        public string EmployeeCode { get; set; } = null!;

        public string EmployeeName { get; set; } = null!;

        public string Address { get; set; } = null!;

        public string ContactNumber { get; set; } = null!;

        public string EducationalQualification { get; set; } = null!;

        public int DepartmentId { get; set; }

        public string DepartmentName { get; set; } = null!;

        public int RoleId { get; set; }

        public string RoleName { get; set; } = null!;

        public int GradeId { get; set; }

        public string GradeName { get; set; } = null!;

        public string? Achievements { get; set; }

        public bool? IsDeleted { get; set; }

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }
}
