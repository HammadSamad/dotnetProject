﻿namespace eproject.Models
{
    public class EmployeeLoginDTO
    {

        public string Username { get; set; } = null!;

        public string PasswordHash { get; set; } = null!;

    }
}
