﻿namespace eproject.Models
{
    public class ClientStaffDTO
    {
        public int ClientStaffId { get; set; }

        public int ClientId { get; set; }

        public string ClientName { get; set; } = null!;

        public int EmployeeId { get; set; }

        public string EmployeeName { get; set; } = null!;

        public bool? IsDeleted { get; set; }

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }
}
