﻿namespace eproject.Models
{
    public class CompanyHistoryDTO
    {
        public int HistoryId { get; set; }

        public DateOnly FoundedDate { get; set; }

        public string? PhotoUrl { get; set; }

        public string HistoryDescription { get; set; } = null!;

        public string Location { get; set; } = null!;

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }
}
