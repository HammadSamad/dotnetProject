﻿namespace eproject.Models
{
    public class EmployeeLoginCreate
    {
        public int LoginId { get; set; }

        public int EmployeeId { get; set; }

        public string Username { get; set; } = null!;

        public string PasswordHash { get; set; } = null!;

        public int RoleId { get; set; }

        public bool? IsDeleted { get; set; }

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }
}
