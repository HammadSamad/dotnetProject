﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace eproject.Models;

public partial class Login
{
    public int LoginId { get; set; }

    public int EmployeeId { get; set; }

    public string Username { get; set; } = null!;

    public string PasswordHash { get; set; } = null!;

    public bool IsDeleted { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    [JsonIgnore]
    public virtual Employee Employee { get; set; } = null!;
}
