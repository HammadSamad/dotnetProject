﻿namespace eproject.Models
{
    public class RegionDTO
    {
        public int RegionId { get; set; }

        public string RegionName { get; set; } = null!;

        public int BranchId { get; set; }

        public string? BranchName { get; set; }

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }
}
