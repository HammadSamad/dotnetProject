﻿namespace eproject.Models
{
    public class EmployeeCreate
    {
        public int EmployeeId { get; set; }
        public string? EmployeeCode { get; set; }
        public IFormFile? PhotoUrl { get; set; }
        public string EmployeeName { get; set; } = null!;
        public string EmployeeEmail { get; set; } = null!;
        public string EmployeeAddress { get; set; } = null!;
        public string ContactNumber { get; set; } = null!;
        public string EducationalQualification { get; set; } = null!;
        public int DepartmentId { get; set; }
        public int RoleId { get; set; }
        public int GradeId { get; set; }
        public string? Achievements { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }

        // 🔹 New fields for login
        public string Username { get; set; } = null!;
        public string Password { get; set; } = null!;
    }
}
