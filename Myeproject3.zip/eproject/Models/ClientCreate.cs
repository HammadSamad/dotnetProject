﻿namespace eproject.Models
{
    public class ClientCreate
    {
        public int ClientId { get; set; }

        public string ClientName { get; set; } = null!;

        public string ClientEmail { get; set; } = null!;

        public IFormFile? PhotoUrl { get; set; }

        public string ClientNumber { get; set; } = null!;

        public string ClientAddress { get; set; } = null!;

        public bool IsDeleted { get; set; }

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }
}
