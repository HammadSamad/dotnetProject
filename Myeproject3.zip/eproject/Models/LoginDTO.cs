﻿using System.ComponentModel.DataAnnotations;

namespace eproject.Models
{
    public class LoginDTO
    {
        [Required]
        public string Username { get; set; } = null!;
        [Required]
        [RegularExpression(
            "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$",
            ErrorMessage = "Password must be at least 8 characters long, contain upper & lower case letters, a number, and a special character."
        )]
        public string Password { get; set; } = null!;
    }
}
