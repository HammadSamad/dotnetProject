﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace eproject.Models;

public partial class Testimonial
{
    public int TestimonialId { get; set; }

    public int ClientId { get; set; }

    public string TestimonialText { get; set; } = null!;

    public string AuthorName { get; set; } = null!;

    public bool IsDeleted { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    [JsonIgnore]
    public virtual Client Client { get; set; } = null!;
}
