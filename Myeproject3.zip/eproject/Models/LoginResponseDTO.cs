﻿namespace eproject.Models
{
    public class LoginResponseDTO
    {
        public int EmployeeId { get; set; }
        public string EmployeeCode { get; set; } = null!;
        public string Username { get; set; } = null!;
        public string EmployeeName { get; set; } = null!;
        public string RoleName { get; set; } = null!;
        public string? PhotoUrl { get; set; }
    }
}
