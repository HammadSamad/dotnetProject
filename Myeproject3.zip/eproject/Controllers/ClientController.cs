﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;
        private readonly IConfiguration _config;

        public ClientController(StarSecuritiesContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        // ------------------------ POST ------------------------
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddClient([FromForm] ClientCreate client)
        {
            if (client == null)
                return BadRequest("No client data sent");

            if (client.PhotoUrl == null)
                return BadRequest("Photo is required");

            try
            {
                var uploadPath = Path.Combine(_config["StoredFilesPath"] ?? "wwwroot/uploads", "Clients");
                Directory.CreateDirectory(uploadPath);

                var extension = Path.GetExtension(client.PhotoUrl.FileName);
                var imageName = Guid.NewGuid().ToString() + extension;
                var filePath = Path.Combine(uploadPath, imageName);

                using (var stream = System.IO.File.Create(filePath))
                {
                    await client.PhotoUrl.CopyToAsync(stream);
                }

                var entity = new Client
                {
                    ClientName = client.ClientName,
                    ClientEmail = client.ClientEmail,
                    PhotoUrl = imageName,
                    ClientNumber = client.ClientNumber,
                    ClientAddress = client.ClientAddress,
                    IsDeleted = false,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                _context.Clients.Add(entity);
                await _context.SaveChangesAsync();

                return Ok("Client added successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        // ------------------------ PUT ------------------------
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateClient(int id, [FromForm] ClientCreate client)
        {
            if (client == null)
                return BadRequest("No client data sent");

            try
            {
                var editClient = await _context.Clients.FindAsync(id);
                if (editClient == null)
                    return NotFound("Client not found");

                // update non-image fields
                editClient.ClientName = client.ClientName;
                editClient.ClientEmail = client.ClientEmail;
                editClient.ClientNumber = client.ClientNumber;
                editClient.ClientAddress = client.ClientAddress;
                editClient.UpdatedAt = DateTime.Now;

                // Only update image if a new one is uploaded
                if (client.PhotoUrl != null && client.PhotoUrl.Length > 0)
                {
                    var uploadPath = Path.Combine(_config["StoredFilesPath"] ?? "wwwroot/uploads", "Clients");
                    Directory.CreateDirectory(uploadPath);

                    var extension = Path.GetExtension(client.PhotoUrl.FileName);
                    var imageName = Guid.NewGuid().ToString() + extension;
                    var filePath = Path.Combine(uploadPath, imageName);

                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await client.PhotoUrl.CopyToAsync(stream);
                    }

                    // delete old image if exists
                    if (!string.IsNullOrEmpty(editClient.PhotoUrl))
                    {
                        var oldImagePath = Path.Combine(uploadPath, editClient.PhotoUrl);
                        if (System.IO.File.Exists(oldImagePath))
                        {
                            System.IO.File.Delete(oldImagePath);
                        }
                    }

                    editClient.PhotoUrl = imageName;
                }

                _context.Clients.Update(editClient);
                await _context.SaveChangesAsync();

                return Ok("Client updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        // ------------------------ DELETE ------------------------
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteClient(int id)
        {
            try
            {
                var client = await _context.Clients.FindAsync(id);
                if (client == null)
                    return NotFound("Client not found");

                client.IsDeleted = true;
                client.UpdatedAt = DateTime.Now;
                await _context.SaveChangesAsync();

                return Ok("Client deleted successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        // ------------------------ GET All ------------------------
        [HttpGet]
        public IActionResult GetClients()
        {
            try
            {
                var clients = _context.Clients
                    .Where(c => !c.IsDeleted)
                    .Select(c => new ClientDTO
                    {
                        ClientId = c.ClientId,
                        ClientName = c.ClientName,
                        ClientEmail = c.ClientEmail,
                        PhotoUrl = c.PhotoUrl,
                        ClientNumber = c.ClientNumber,
                        ClientAddress = c.ClientAddress,
                        IsDeleted = c.IsDeleted,
                        CreatedAt = c.CreatedAt,
                        UpdatedAt = c.UpdatedAt
                    })
                    .ToList();

                if (clients.Count == 0)
                    return NotFound("No clients found");

                return Ok(clients);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        // ------------------------ GET by ID ------------------------
        [HttpGet("{id}")]
        public IActionResult GetClientById(int id)
        {
            try
            {
                var data = _context.Clients
                    .Where(c => c.ClientId == id && !c.IsDeleted)
                    .Select(c => new ClientDTO
                    {
                        ClientId = c.ClientId,
                        ClientName = c.ClientName,
                        ClientEmail = c.ClientEmail,
                        PhotoUrl = c.PhotoUrl,
                        ClientNumber = c.ClientNumber,
                        ClientAddress = c.ClientAddress,
                        IsDeleted = c.IsDeleted,
                        CreatedAt = c.CreatedAt,
                        UpdatedAt = c.UpdatedAt
                    })
                    .FirstOrDefault();

                if (data == null)
                    return NotFound("Client not found");

                return Ok(data);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }
    }
}
