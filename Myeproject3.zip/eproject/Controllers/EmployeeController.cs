﻿using eproject.Data;
using eproject.Helpers;
using eproject.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class EmployeeController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;
        private readonly IConfiguration _config;

        public EmployeeController(StarSecuritiesContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        // -------------------------------------------------------------
        // POST: api/Employee → Add employee + login (Admin only)
        // -------------------------------------------------------------
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddEmployee([FromForm] EmployeeCreate employee)
        {
            if (employee == null) return BadRequest("Invalid employee data.");
            if (string.IsNullOrWhiteSpace(employee.EmployeeName) ||
                string.IsNullOrWhiteSpace(employee.EmployeeEmail) ||
                string.IsNullOrWhiteSpace(employee.Username) ||
                string.IsNullOrWhiteSpace(employee.Password) ||
                employee.DepartmentId <= 0 || employee.RoleId <= 0 || employee.GradeId <= 0)
            {
                return BadRequest("Required fields are missing or invalid.");
            }

            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Upload photo
                string? imageName = null;
                if (employee.PhotoUrl != null && employee.PhotoUrl.Length > 0)
                {
                    var uploadPath = Path.Combine(_config["StoredFilesPath"] ?? "wwwroot/uploads", "Employees");
                    Directory.CreateDirectory(uploadPath);

                    var ext = Path.GetExtension(employee.PhotoUrl.FileName);
                    imageName = Guid.NewGuid() + ext;
                    var filePath = Path.Combine(uploadPath, imageName);

                    using var stream = System.IO.File.Create(filePath);
                    await employee.PhotoUrl.CopyToAsync(stream);
                }

                var newEmployee = new Employee
                {
                    EmployeeCode = employee.EmployeeCode,
                    PhotoUrl = imageName,
                    EmployeeName = employee.EmployeeName,
                    EmployeeEmail = employee.EmployeeEmail,
                    EmployeeAddress = employee.EmployeeAddress,
                    ContactNumber = employee.ContactNumber,
                    EducationalQualification = employee.EducationalQualification,
                    DepartmentId = employee.DepartmentId,
                    RoleId = employee.RoleId,
                    GradeId = employee.GradeId,
                    Achievements = employee.Achievements,
                    IsDeleted = false,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                _context.Employees.Add(newEmployee);
                await _context.SaveChangesAsync();

                if (await _context.Logins.AnyAsync(l => l.Username == employee.Username && !l.IsDeleted))
                    return BadRequest("Username already exists.");

                var login = new Login
                {
                    EmployeeId = newEmployee.EmployeeId,
                    Username = employee.Username,
                    PasswordHash = PasswordHasher.HashPassword(employee.Password),
                    IsDeleted = false,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                _context.Logins.Add(login);
                await _context.SaveChangesAsync();

                await transaction.CommitAsync();
                return Ok(new { message = "Employee created successfully." });
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return BadRequest(ex.Message);
            }
        }

        // -------------------------------------------------------------
        // PUT: api/Employee/{id} → Update all employee + login info (Admin only)
        // -------------------------------------------------------------
        [HttpPut("{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateEmployee(int id, [FromForm] EmployeeCreate model)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee == null || employee.IsDeleted) return NotFound("Employee not found");

            var login = await _context.Logins.FirstOrDefaultAsync(l => l.EmployeeId == id && !l.IsDeleted);
            if (login == null) return NotFound("Login not found");

            // --- Update employee fields ---
            employee.EmployeeCode = model.EmployeeCode ?? employee.EmployeeCode;
            employee.EmployeeName = model.EmployeeName ?? employee.EmployeeName;
            employee.EmployeeEmail = model.EmployeeEmail ?? employee.EmployeeEmail;
            employee.EmployeeAddress = model.EmployeeAddress ?? employee.EmployeeAddress;
            employee.ContactNumber = model.ContactNumber ?? employee.ContactNumber;
            employee.EducationalQualification = model.EducationalQualification ?? employee.EducationalQualification;
            employee.Achievements = model.Achievements ?? employee.Achievements;
            employee.DepartmentId = model.DepartmentId > 0 ? model.DepartmentId : employee.DepartmentId;
            employee.RoleId = model.RoleId > 0 ? model.RoleId : employee.RoleId;
            employee.GradeId = model.GradeId > 0 ? model.GradeId : employee.GradeId;

            // Photo update
            if (model.PhotoUrl != null && model.PhotoUrl.Length > 0)
            {
                var uploadPath = Path.Combine(_config["StoredFilesPath"] ?? "wwwroot/uploads", "Employees");
                Directory.CreateDirectory(uploadPath);

                var ext = Path.GetExtension(model.PhotoUrl.FileName);
                var imageName = Guid.NewGuid() + ext;
                var filePath = Path.Combine(uploadPath, imageName);

                using var stream = System.IO.File.Create(filePath);
                await model.PhotoUrl.CopyToAsync(stream);

                if (!string.IsNullOrEmpty(employee.PhotoUrl))
                {
                    var oldFile = Path.Combine(uploadPath, employee.PhotoUrl);
                    if (System.IO.File.Exists(oldFile)) System.IO.File.Delete(oldFile);
                }

                employee.PhotoUrl = imageName;
            }

            employee.UpdatedAt = DateTime.Now;

            // --- Update login fields ---
            if (!string.IsNullOrWhiteSpace(model.Username) && login.Username != model.Username)
            {
                if (await _context.Logins.AnyAsync(l => l.Username == model.Username && l.EmployeeId != id && !l.IsDeleted))
                    return BadRequest("Username already exists.");
                login.Username = model.Username;
            }

            if (!string.IsNullOrWhiteSpace(model.Password))
                login.PasswordHash = PasswordHasher.HashPassword(model.Password);

            login.UpdatedAt = DateTime.Now;

            await _context.SaveChangesAsync();
            return Ok(new { message = "Employee updated successfully" });
        }

        // -------------------------------------------------------------
        // DELETE: api/Employee/{id} → Soft delete employee + login
        // -------------------------------------------------------------
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee == null || employee.IsDeleted) return NotFound("Employee not found");

            employee.IsDeleted = true;
            employee.UpdatedAt = DateTime.Now;

            var login = await _context.Logins.FirstOrDefaultAsync(l => l.EmployeeId == id && !l.IsDeleted);
            if (login != null)
            {
                login.IsDeleted = true;
                login.UpdatedAt = DateTime.Now;
            }

            await _context.SaveChangesAsync();
            return Ok(new { message = "Employee deleted successfully" });
        }

        // -------------------------------------------------------------
        // GET: api/Employee → List all employees (ignores deleted)
        // -------------------------------------------------------------
        [HttpGet]
        public async Task<IActionResult> GetEmployees()
        {
            var employees = await _context.Employees
                .Include(e => e.Department)
                .Include(e => e.Role)
                .Include(e => e.Grade)
                .Where(e => !e.IsDeleted)
                .Select(e => new
                {
                    e.EmployeeId,
                    e.EmployeeCode,
                    e.EmployeeName,
                    e.EmployeeEmail,
                    e.EmployeeAddress,
                    e.ContactNumber,
                    e.EducationalQualification,
                    e.DepartmentId,
                    e.Department.DepartmentName,
                    e.RoleId,
                    e.Role.RoleName,
                    e.GradeId,
                    e.Grade.GradeName,
                    e.Achievements,
                    e.PhotoUrl,
                    e.CreatedAt,
                    e.UpdatedAt
                }).ToListAsync();

            return Ok(employees);
        }

        // -------------------------------------------------------------
        // GET: api/Employee/{id} → Single employee (ignores deleted)
        // -------------------------------------------------------------
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetEmployeeById(int id)
        {
            var employee = await _context.Employees
                .Include(e => e.Department)
                .Include(e => e.Role)
                .Include(e => e.Grade)
                .Where(e => e.EmployeeId == id && !e.IsDeleted)
                .Select(e => new
                {
                    e.EmployeeId,
                    e.EmployeeCode,
                    e.EmployeeName,
                    e.EmployeeEmail,
                    e.EmployeeAddress,
                    e.ContactNumber,
                    e.EducationalQualification,
                    e.DepartmentId,
                    e.Department.DepartmentName,
                    e.RoleId,
                    e.Role.RoleName,
                    e.GradeId,
                    e.Grade.GradeName,
                    e.Achievements,
                    e.PhotoUrl,
                    e.CreatedAt,
                    e.UpdatedAt
                }).FirstOrDefaultAsync();

            return employee == null ? NotFound("Employee not found") : Ok(employee);
        }
    }
}
