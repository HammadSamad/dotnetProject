﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanyHistoryController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;
        private readonly IConfiguration _config;

        public CompanyHistoryController(StarSecuritiesContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        // -------------------------------------------------------
        // POST: Add Company History with image upload
        // -------------------------------------------------------
        [HttpPost]
        public async Task<IActionResult> AddCompanyHistory([FromForm] CompanyHistoryCreate companyHistory)
        {
            if (companyHistory == null)
                return BadRequest("Invalid request");

            string? imageName = null;
            if (companyHistory.PhotoUrl != null && companyHistory.PhotoUrl.Length > 0)
            {
                var uploadPath = Path.Combine(_config["StoredFilesPath"] ?? "wwwroot/uploads", "CompanyHistory");
                Directory.CreateDirectory(uploadPath);

                var extension = Path.GetExtension(companyHistory.PhotoUrl.FileName);
                imageName = Guid.NewGuid().ToString() + extension;
                var filePath = Path.Combine(uploadPath, imageName);

                using (var stream = System.IO.File.Create(filePath))
                {
                    await companyHistory.PhotoUrl.CopyToAsync(stream);
                }
            }

            var entity = new CompanyHistory
            {
                FoundedDate = companyHistory.FoundedDate,
                HistoryDescription = companyHistory.HistoryDescription,
                Location = companyHistory.Location,
                PhotoUrl = imageName,
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now
            };

            _context.CompanyHistories.Add(entity);
            await _context.SaveChangesAsync();

            return Ok("Company History added successfully");
        }

        // -------------------------------------------------------
        // PUT: Update Company History
        // -------------------------------------------------------
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCompanyHistory([FromForm] CompanyHistoryCreate companyHistory, int id)
        {
            var edit = await _context.CompanyHistories.FindAsync(id);
            if (edit == null)
                return NotFound("Company History not found");

            // update fields
            edit.FoundedDate = companyHistory.FoundedDate;
            edit.HistoryDescription = companyHistory.HistoryDescription;
            edit.Location = companyHistory.Location;
            edit.UpdatedAt = DateTime.Now;

            // handle new image if provided
            if (companyHistory.PhotoUrl != null && companyHistory.PhotoUrl.Length > 0)
            {
                var uploadPath = Path.Combine(_config["StoredFilesPath"] ?? "wwwroot/uploads", "CompanyHistory");
                Directory.CreateDirectory(uploadPath);

                var extension = Path.GetExtension(companyHistory.PhotoUrl.FileName);
                var newImageName = Guid.NewGuid().ToString() + extension;
                var newFilePath = Path.Combine(uploadPath, newImageName);

                using (var stream = System.IO.File.Create(newFilePath))
                {
                    await companyHistory.PhotoUrl.CopyToAsync(stream);
                }

                // optional: delete old image
                if (!string.IsNullOrEmpty(edit.PhotoUrl))
                {
                    var oldPath = Path.Combine(uploadPath, edit.PhotoUrl);
                    if (System.IO.File.Exists(oldPath))
                    {
                        System.IO.File.Delete(oldPath);
                    }
                }

                edit.PhotoUrl = newImageName;
            }

            _context.CompanyHistories.Update(edit);
            await _context.SaveChangesAsync();

            return Ok("Company History updated successfully");
        }

        // -------------------------------------------------------
        // DELETE: Delete Company History
        // -------------------------------------------------------
        [HttpDelete("{id}")]
        public IActionResult DeleteCompanyHistory(int id)
        {
            var del = _context.CompanyHistories.Find(id);
            if (del == null)
                return NotFound("Company History not found");

            _context.CompanyHistories.Remove(del);
            _context.SaveChanges();
            return Ok("Company History deleted successfully");
        }

        // -------------------------------------------------------
        // GET: All Company History
        // -------------------------------------------------------
        [HttpGet]
        public IActionResult GetCompanyHistory()
        {
            var data = _context.CompanyHistories
                .Select(ch => new CompanyHistoryDTO
                {
                    HistoryId = ch.HistoryId,
                    FoundedDate = ch.FoundedDate,
                    HistoryDescription = ch.HistoryDescription,
                    Location = ch.Location,
                    PhotoUrl = ch.PhotoUrl,
                    CreatedAt = ch.CreatedAt,
                    UpdatedAt = ch.UpdatedAt
                }).ToList();

            if (data.Count == 0)
                return NotFound("No company history found");

            return Ok(data);
        }

        // -------------------------------------------------------
        // GET: Company History By Id
        // -------------------------------------------------------
        [HttpGet("{id}")]
        public IActionResult GetCompanyHistoryById(int id)
        {
            var data = _context.CompanyHistories
                .Where(ch => ch.HistoryId == id)
                .Select(ch => new CompanyHistoryDTO
                {
                    HistoryId = ch.HistoryId,
                    FoundedDate = ch.FoundedDate,
                    HistoryDescription = ch.HistoryDescription,
                    Location = ch.Location,
                    PhotoUrl = ch.PhotoUrl,
                    CreatedAt = ch.CreatedAt,
                    UpdatedAt = ch.UpdatedAt
                })
                .FirstOrDefault();

            if (data == null)
                return NotFound("Company History not found");

            return Ok(data);
        }
    }
}
