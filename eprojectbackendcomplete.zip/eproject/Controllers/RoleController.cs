﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Mvc;

[Route("api/[controller]")]
[ApiController]
public class RoleController : ControllerBase
{
    private readonly StarSecuritiesContext _context;

    public RoleController(StarSecuritiesContext context)
    {
        _context = context;
    }

    [HttpPost]
    public IActionResult AddRole(Role role)
    {
        if (string.IsNullOrWhiteSpace(role.RoleName))
            return BadRequest("Role name is required");

        _context.Roles.Add(role);
        _context.SaveChanges();
        return Ok(new { message = "Role added successfully", role });
    }

    [HttpPut("{id}")]
    public IActionResult UpdateRole(int id, Role role)
    {
        var editRole = _context.Roles.Find(id);
        if (editRole == null)
            return NotFound("Role not found");

        editRole.RoleName = role.RoleName;
        _context.SaveChanges();
        return Ok(new { message = "Role updated successfully", role = editRole });
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteRole(int id)
    {
        var role = _context.Roles.Find(id);
        if (role == null)
            return NotFound("Role not found");

        _context.Roles.Remove(role);
        _context.SaveChanges();
        return Ok(new { message = "Role deleted successfully", role });
    }

    [HttpGet]
    public IActionResult GetRoles()
    {
        var roles = _context.Roles.ToList();
        if (!roles.Any())
            return NotFound("No roles found");

        return Ok(roles);
    }

    [HttpGet("{id}")]
    public IActionResult GetRoleById(int id)
    {
        var role = _context.Roles.Find(id);
        if (role == null)
            return NotFound("Role not found");

        return Ok(role);
    }
}
