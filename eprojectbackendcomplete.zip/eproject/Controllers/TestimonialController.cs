﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestimonialController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;

        public TestimonialController(StarSecuritiesContext context)
        {
            _context = context;
        }

        //-----------------------------------------------------------
        //----------------------- POST ------------------------------
        //-----------------------------------------------------------

        [HttpPost]
        public async Task<IActionResult> AddTestimonial([FromBody] TestimonialCreate testimonial)
        {
            try
            {
                var newTestimonial = new Testimonial
                {
                    ClientId = testimonial.ClientId,
                    TestimonialText = testimonial.TestimonialText,
                    AuthorName = testimonial.AuthorName,
                    IsDeleted = false,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                await _context.Testimonials.AddAsync(newTestimonial);
                await _context.SaveChangesAsync();

                return Ok("Testimonial added successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //------------------------- PUT -----------------------------
        //-----------------------------------------------------------

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTestimonial(int id, [FromBody] TestimonialCreate testimonial)
        {
            try
            {
                var existingTestimonial = await _context.Testimonials.FindAsync(id);
                if (existingTestimonial == null)
                {
                    return NotFound("Testimonial not found");
                }

                existingTestimonial.ClientId = testimonial.ClientId;
                existingTestimonial.TestimonialText = testimonial.TestimonialText;
                existingTestimonial.AuthorName = testimonial.AuthorName;
                existingTestimonial.UpdatedAt = DateTime.Now;

                await _context.SaveChangesAsync();
                return Ok("Testimonial updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //------------------------ DELETE ---------------------------
        //-----------------------------------------------------------

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTestimonial(int id)
        {
            try
            {
                var existingTestimonial = await _context.Testimonials.FindAsync(id);
                if (existingTestimonial == null)
                {
                    return NotFound("Testimonial not found");
                }

                existingTestimonial.IsDeleted = true;
                existingTestimonial.UpdatedAt = DateTime.Now;

                await _context.SaveChangesAsync();
                return Ok("Testimonial deleted successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //----------------------------GET----------------------------
        //-----------------------------------------------------------

        [HttpGet]
        public async Task<IActionResult> GetTestimonials()
        {
            try
            {
                var testimonials = await _context.Testimonials
                    .Where(t => !t.IsDeleted)
                    .Select(t => new TestimonialDTO
                    {
                        TestimonialId = t.TestimonialId,
                        ClientId = t.ClientId,
                        photoUrl = t.Client.PhotoUrl,
                        clientName = t.Client.ClientName,
                        TestimonialText = t.TestimonialText,
                        AuthorName = t.AuthorName,
                        IsDeleted = t.IsDeleted,
                        CreatedAt = t.CreatedAt,
                        UpdatedAt = t.UpdatedAt
                    })
                    .ToListAsync();

                return Ok(testimonials);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //------------------------------------------------------------
        //------------------------GET BY ID---------------------------
        //------------------------------------------------------------

        [HttpGet("{id}")]
        public async Task<IActionResult> GetTestimonialById(int id)
        {
            try
            {
                var testimonial = await _context.Testimonials
                    .Where(t => t.TestimonialId == id && !t.IsDeleted)
                    .Select(t => new TestimonialDTO
                    {
                        TestimonialId = t.TestimonialId,
                        ClientId = t.ClientId,
                        photoUrl = t.Client.PhotoUrl,
                        clientName = t.Client.ClientName,
                        TestimonialText = t.TestimonialText,
                        AuthorName = t.AuthorName,
                        IsDeleted = t.IsDeleted,
                        CreatedAt = t.CreatedAt,
                        UpdatedAt = t.UpdatedAt
                    })
                    .FirstOrDefaultAsync();

                if (testimonial == null)
                {
                    return NotFound("Testimonial not found");
                }

                return Ok(testimonial);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }
    }
}
