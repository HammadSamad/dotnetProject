﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;
        private readonly IConfiguration _config;

        public EmployeeController(StarSecuritiesContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        // -------------------------------------------------------------
        // POST: api/Employee
        // -------------------------------------------------------------
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddEmployee([FromForm] EmployeeCreate employee)
        {
            if (employee == null) return BadRequest("Invalid employee data.");

            try
            {
                string? imageName = null;

                if (employee.PhotoUrl != null && employee.PhotoUrl.Length > 0)
                {
                    var uploadPath = _config["StoredFilesPath"];
                    if (!Directory.Exists(uploadPath)) Directory.CreateDirectory(uploadPath);

                    var ext = Path.GetExtension(employee.PhotoUrl.FileName);
                    imageName = Guid.NewGuid() + ext;
                    var filePath = Path.Combine(uploadPath, imageName);

                    using var stream = System.IO.File.Create(filePath);
                    await employee.PhotoUrl.CopyToAsync(stream);
                }

                var newEmployee = new Employee
                {
                    EmployeeCode = employee.EmployeeCode,
                    PhotoUrl = imageName,
                    EmployeeName = employee.EmployeeName,
                    EmployeeEmail = employee.EmployeeEmail,
                    EmployeeAddress = employee.EmployeeAddress,
                    ContactNumber = employee.ContactNumber,
                    EducationalQualification = employee.EducationalQualification,
                    DepartmentId = employee.DepartmentId,
                    RoleId = employee.RoleId,
                    GradeId = employee.GradeId,
                    Achievements = employee.Achievements,
                    IsDeleted = false,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                _context.Employees.Add(newEmployee);
                await _context.SaveChangesAsync();
                return Ok("Employee added successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // -------------------------------------------------------------
        // PUT: api/Employee/{id}
        // -------------------------------------------------------------
        [HttpPut("{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateEmployee(int id, [FromForm] EmployeeCreate employee)
        {
            if (employee == null) return BadRequest("Invalid employee data.");

            try
            {
                var existing = await _context.Employees.FindAsync(id);
                if (existing == null) return NotFound("Employee not found");

                existing.EmployeeCode = employee.EmployeeCode;
                existing.EmployeeName = employee.EmployeeName;
                existing.EmployeeEmail = employee.EmployeeEmail;
                existing.EmployeeAddress = employee.EmployeeAddress;
                existing.ContactNumber = employee.ContactNumber;
                existing.EducationalQualification = employee.EducationalQualification;
                existing.DepartmentId = employee.DepartmentId;
                existing.RoleId = employee.RoleId;
                existing.GradeId = employee.GradeId;
                existing.Achievements = employee.Achievements;
                existing.UpdatedAt = DateTime.Now;

                // Only update image if a new one is uploaded
                if (employee.PhotoUrl != null && employee.PhotoUrl.Length > 0)
                {
                    var uploadPath = _config["StoredFilesPath"];
                    if (!Directory.Exists(uploadPath)) Directory.CreateDirectory(uploadPath);

                    var ext = Path.GetExtension(employee.PhotoUrl.FileName);
                    var imageName = Guid.NewGuid() + ext;
                    var filePath = Path.Combine(uploadPath, imageName);

                    using var stream = System.IO.File.Create(filePath);
                    await employee.PhotoUrl.CopyToAsync(stream);

                    // optional: delete old file
                    if (!string.IsNullOrEmpty(existing.PhotoUrl))
                    {
                        var oldFile = Path.Combine(uploadPath, existing.PhotoUrl);
                        if (System.IO.File.Exists(oldFile)) System.IO.File.Delete(oldFile);
                    }

                    existing.PhotoUrl = imageName;
                }

                _context.Employees.Update(existing);
                await _context.SaveChangesAsync();
                return Ok("Employee updated successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // -------------------------------------------------------------
        // DELETE: api/Employee/{id}
        // -------------------------------------------------------------
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            try
            {
                var employee = await _context.Employees.FindAsync(id);
                if (employee == null) return NotFound("Employee not found");

                employee.IsDeleted = true;
                employee.UpdatedAt = DateTime.Now;

                await _context.SaveChangesAsync();
                return Ok("Employee deleted successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // -------------------------------------------------------------
        // GET: api/Employee
        // -------------------------------------------------------------
        [HttpGet]
        public async Task<IActionResult> GetEmployees()
        {
            try
            {
                var employees = await _context.Employees
                    .Include(e => e.Department)
                    .Include(e => e.Role)
                    .Include(e => e.Grade)
                    .Where(e => !e.IsDeleted)
                    .Select(e => new EmployeeDTO
                    {
                        EmployeeId = e.EmployeeId,
                        EmployeeCode = e.EmployeeCode,
                        PhotoUrl = e.PhotoUrl,
                        EmployeeName = e.EmployeeName,
                        EmployeeEmail = e.EmployeeEmail,
                        EmployeeAddress = e.EmployeeAddress,
                        ContactNumber = e.ContactNumber,
                        EducationalQualification = e.EducationalQualification,
                        DepartmentId = e.DepartmentId,
                        DepartmentName = e.Department.DepartmentName,
                        RoleId = e.RoleId,
                        RoleName = e.Role.RoleName,
                        GradeId = e.GradeId,
                        GradeName = e.Grade.GradeName,
                        Achievements = e.Achievements,
                        IsDeleted = e.IsDeleted,
                        CreatedAt = e.CreatedAt,
                        UpdatedAt = e.UpdatedAt
                    }).ToListAsync();

                return Ok(employees);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // -------------------------------------------------------------
        // GET: api/Employee/{id}
        // -------------------------------------------------------------
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetEmployeeById(int id)
        {
            try
            {
                var employee = await _context.Employees
                    .Include(e => e.Department)
                    .Include(e => e.Role)
                    .Include(e => e.Grade)
                    .Where(e => e.EmployeeId == id && !e.IsDeleted)
                    .Select(e => new EmployeeDTO
                    {
                        EmployeeId = e.EmployeeId,
                        EmployeeCode = e.EmployeeCode,
                        PhotoUrl = e.PhotoUrl,
                        EmployeeName = e.EmployeeName,
                        EmployeeEmail = e.EmployeeEmail,
                        EmployeeAddress = e.EmployeeAddress,
                        ContactNumber = e.ContactNumber,
                        EducationalQualification = e.EducationalQualification,
                        DepartmentId = e.DepartmentId,
                        DepartmentName = e.Department.DepartmentName,
                        RoleId = e.RoleId,
                        RoleName = e.Role.RoleName,
                        GradeId = e.GradeId,
                        GradeName = e.Grade.GradeName,
                        Achievements = e.Achievements,
                        IsDeleted = e.IsDeleted,
                        CreatedAt = e.CreatedAt,
                        UpdatedAt = e.UpdatedAt
                    }).FirstOrDefaultAsync();

                if (employee == null) return NotFound("Employee not found");

                return Ok(employee);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
