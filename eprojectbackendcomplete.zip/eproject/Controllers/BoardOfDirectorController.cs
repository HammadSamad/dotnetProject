﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Mvc;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BoardOfDirectorController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;
        private readonly IConfiguration _config;

        public BoardOfDirectorController(StarSecuritiesContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        //----------------------------------------------------------------------
        // POST Create Board of Director with image upload
        //----------------------------------------------------------------------
        [HttpPost]
        public async Task<IActionResult> AddBoardofDirector([FromForm] BoardOfDirectorCreate boardOfDirector)
        {
            try
            {
                if (boardOfDirector == null)
                    return BadRequest("Invalid request");

                if (boardOfDirector.PhotoUrl == null)
                    return BadRequest("Photo is required");

                var uploadPath = _config["StoredFilesPath"];
                if (!Directory.Exists(uploadPath))
                    Directory.CreateDirectory(uploadPath);

                var extension = Path.GetExtension(boardOfDirector.PhotoUrl.FileName);
                var imageName = Guid.NewGuid() + extension;
                var filePath = Path.Combine(uploadPath, imageName);

                using (var stream = System.IO.File.Create(filePath))
                {
                    await boardOfDirector.PhotoUrl.CopyToAsync(stream);
                }

                var boardOfDirectorData = new BoardOfDirector
                {
                    Name = boardOfDirector.Name,
                    Designation = boardOfDirector.Designation,
                    Bio = boardOfDirector.Bio,
                    PhotoUrl = imageName,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                _context.BoardOfDirectors.Add(boardOfDirectorData);
                await _context.SaveChangesAsync();

                // Return the newly created record as DTO
                var dto = new BoardOfDirectorDTO
                {
                    DirectorId = boardOfDirectorData.DirectorId,
                    Name = boardOfDirectorData.Name,
                    Designation = boardOfDirectorData.Designation,
                    Bio = boardOfDirectorData.Bio,
                    PhotoUrl = boardOfDirectorData.PhotoUrl,
                    CreatedAt = boardOfDirectorData.CreatedAt,
                    UpdatedAt = boardOfDirectorData.UpdatedAt
                };

                return Ok(dto);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------------
        // PUT Update Board of Director with optional image upload
        //----------------------------------------------------------------------
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateBoardofDirector([FromForm] BoardOfDirectorCreate updateBoardOfDirector, int id)
        {
            try
            {
                var editBoardOfDirector = await _context.BoardOfDirectors.FindAsync(id);
                if (editBoardOfDirector == null)
                    return NotFound("Board of Director not found");

                editBoardOfDirector.Name = updateBoardOfDirector.Name;
                editBoardOfDirector.Designation = updateBoardOfDirector.Designation;
                editBoardOfDirector.Bio = updateBoardOfDirector.Bio;
                editBoardOfDirector.UpdatedAt = DateTime.Now;

                if (updateBoardOfDirector.PhotoUrl != null && updateBoardOfDirector.PhotoUrl.Length > 0)
                {
                    var uploadPath = _config["StoredFilesPath"];
                    if (!Directory.Exists(uploadPath))
                        Directory.CreateDirectory(uploadPath);

                    var extension = Path.GetExtension(updateBoardOfDirector.PhotoUrl.FileName);
                    var imageName = Guid.NewGuid() + extension;
                    var filePath = Path.Combine(uploadPath, imageName);

                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await updateBoardOfDirector.PhotoUrl.CopyToAsync(stream);
                    }

                    // Delete old image
                    if (!string.IsNullOrEmpty(editBoardOfDirector.PhotoUrl))
                    {
                        var oldImagePath = Path.Combine(uploadPath, editBoardOfDirector.PhotoUrl);
                        if (System.IO.File.Exists(oldImagePath))
                        {
                            System.IO.File.Delete(oldImagePath);
                        }
                    }

                    editBoardOfDirector.PhotoUrl = imageName;
                }

                _context.BoardOfDirectors.Update(editBoardOfDirector);
                await _context.SaveChangesAsync();

                return Ok("Board of Director updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------------
        // DELETE Board of Director
        //----------------------------------------------------------------------
        [HttpDelete("{id}")]
        public async Task<IActionResult> DelBoardOfDirector(int id)
        {
            try
            {
                var delboardOfDirector = await _context.BoardOfDirectors.FindAsync(id);
                if (delboardOfDirector == null)
                    return NotFound("Board of Director not found");

                _context.BoardOfDirectors.Remove(delboardOfDirector);
                await _context.SaveChangesAsync();

                return Ok("Board of Director deleted successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-------------------------------------------
        // GET All Board of Directors
        //-------------------------------------------
        [HttpGet]
        public IActionResult GetBoardOfDirectors()
        {
            try
            {
                var boardOfDirectors = _context.BoardOfDirectors.ToList();
                if (boardOfDirectors == null || boardOfDirectors.Count == 0)
                    return NotFound("No Board of Directors found");

                return Ok(boardOfDirectors);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-------------------------------------------
        // GET Board of Director BY ID
        //-------------------------------------------
        [HttpGet("{id}")]
        public IActionResult GetBoardOfDirectorById(int id)
        {
            try
            {
                var data = _context.BoardOfDirectors
                    .Where(bod => bod.DirectorId == id)
                    .Select(bod => new BoardOfDirectorDTO
                    {
                        DirectorId = bod.DirectorId,
                        Name = bod.Name,
                        Designation = bod.Designation,
                        Bio = bod.Bio,
                        PhotoUrl = bod.PhotoUrl,
                        CreatedAt = bod.CreatedAt,
                        UpdatedAt = bod.UpdatedAt
                    })
                    .FirstOrDefault();

                if (data == null)
                    return NotFound("Board of Director not found");

                return Ok(data);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }
    }
}
