﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;

        public DepartmentController(StarSecuritiesContext context)
        {
            _context = context;
        }

        //----------------------------------------------------------------
        //------------------------ POST ----------------------------------
        //----------------------------------------------------------------

        [HttpPost]
        public IActionResult AddDepartment(Department department)
        {
            try
            {
                if (department != null)
                {
                    var departments = _context.Departments.Add(department);
                    _context.SaveChanges();
                }
                return Ok("Department added successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ PUT -----------------------------------
        //----------------------------------------------------------------

        [HttpPut]
        public IActionResult UpdateDepartment(Department department, int id)
        {
            try
            {
                var editDepartment = _context.Departments.Find(id);
                if (editDepartment != null)
                {
                    editDepartment.DepartmentName = department.DepartmentName;
                }
                _context.SaveChanges();
                return Ok("Department updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ DELETE --------------------------------
        //----------------------------------------------------------------

        [HttpDelete]
        public IActionResult DeleteDepartment(int id)
        {
            try
            {
                var deleteDepartment = _context.Departments.Find(id);
                if (deleteDepartment != null)
                {
                    _context.Departments.Remove(deleteDepartment);
                    _context.SaveChanges();
                }
                return Ok("Department deleted successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ GET -----------------------------------
        //----------------------------------------------------------------

        [HttpGet]
        public IActionResult GetAllDepartments()
        {
            try
            {
                var departments = _context.Departments.ToList();
                return Ok(departments);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        //------------------------ GET BY ID -----------------------------
        //----------------------------------------------------------------

        [HttpGet("{id}")]
        public IActionResult GetDepartmentById(int id)
        {
            try
            {
                var department = _context.Departments.Where(d => d.DepartmentId == id).FirstOrDefault();
                if (department != null)
                {
                    return Ok(department);
                }
                return NotFound("Department not found");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }



    }
}
