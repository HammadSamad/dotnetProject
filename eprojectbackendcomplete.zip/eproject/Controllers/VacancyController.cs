﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VacancyController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;

        public VacancyController(StarSecuritiesContext context)
        {
            _context = context;
        }

        //-----------------------------------------------------------
        //----------------------- POST ------------------------------
        //-----------------------------------------------------------

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddVacancy([FromBody] VacancyCreate vacancy)
        {
            try
            {
                if (vacancy == null)
                    return BadRequest("Vacancy data is required");

                var newVacancy = new Vacancy
                {
                    Title = vacancy.Title,
                    DepartmentId = vacancy.DepartmentId,
                    Description = vacancy.Description,
                    OpeningDate = vacancy.OpeningDate,
                    ClosingDate = vacancy.ClosingDate,
                    Status = vacancy.Status,
                    IsDeleted = false,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                await _context.Vacancies.AddAsync(newVacancy);
                await _context.SaveChangesAsync();

                return Ok("Vacancy added successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //------------------------- PUT -----------------------------
        //-----------------------------------------------------------

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateVacancy(int id, [FromBody] VacancyCreate vacancy)
        {
            try
            {
                var existingVacancy = await _context.Vacancies.FindAsync(id);
                if (existingVacancy == null)
                {
                    return NotFound("Vacancy not found");
                }

                existingVacancy.Title = vacancy.Title;
                existingVacancy.DepartmentId = vacancy.DepartmentId;
                existingVacancy.Description = vacancy.Description;
                existingVacancy.OpeningDate = vacancy.OpeningDate;
                existingVacancy.ClosingDate = vacancy.ClosingDate;
                existingVacancy.Status = vacancy.Status;
                existingVacancy.UpdatedAt = DateTime.Now;

                _context.Vacancies.Update(existingVacancy);
                await _context.SaveChangesAsync();

                return Ok("Vacancy updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //------------------------- DELETE --------------------------
        //-----------------------------------------------------------

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteVacancy(int id)
        {
            try
            {
                var existingVacancy = await _context.Vacancies.FindAsync(id);
                if (existingVacancy == null)
                {
                    return NotFound("Vacancy not found");
                }

                existingVacancy.IsDeleted = true;
                existingVacancy.UpdatedAt = DateTime.Now;

                _context.Vacancies.Update(existingVacancy);
                await _context.SaveChangesAsync();

                return Ok("Vacancy deleted successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //------------------------- GET -----------------------------
        //-----------------------------------------------------------

        [HttpGet]
        public async Task<IActionResult> GetAllVacancies()
        {
            try
            {
                var vacancies = await _context.Vacancies
                    .Include(v => v.Department)
                    .Where(v => !v.IsDeleted)
                    .Select(v => new VacancyDTO
                    {
                        VacancyId = v.VacancyId,
                        Title = v.Title,
                        DepartmentId = v.DepartmentId,
                        DepartmentName = v.Department.DepartmentName,
                        Description = v.Description,
                        OpeningDate = v.OpeningDate,
                        ClosingDate = v.ClosingDate,
                        Status = v.Status,
                        IsDeleted = v.IsDeleted,
                        CreatedAt = v.CreatedAt,
                        UpdatedAt = v.UpdatedAt
                    })
                    .ToListAsync();

                return Ok(vacancies);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //----------------------- GET BY ID -------------------------
        //-----------------------------------------------------------

        [HttpGet("{id}")]
        public async Task<IActionResult> GetVacancyById(int id)
        {
            try
            {
                var vacancy = await _context.Vacancies
                    .Include(v => v.Department)
                    .Where(v => !v.IsDeleted && v.VacancyId == id)
                    .Select(v => new VacancyDTO
                    {
                        VacancyId = v.VacancyId,
                        Title = v.Title,
                        DepartmentId = v.DepartmentId,
                        DepartmentName = v.Department.DepartmentName,
                        Description = v.Description,
                        OpeningDate = v.OpeningDate,
                        ClosingDate = v.ClosingDate,
                        Status = v.Status,
                        IsDeleted = v.IsDeleted,
                        CreatedAt = v.CreatedAt,
                        UpdatedAt = v.UpdatedAt
                    })
                    .FirstOrDefaultAsync();

                if (vacancy == null)
                {
                    return NotFound("Vacancy not found");
                }

                return Ok(vacancy);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }
    }
}
