﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServiceController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;
        private readonly IConfiguration _config;

        public ServiceController(StarSecuritiesContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        //-----------------------------------------------------------
        //------------------------ POST -----------------------------
        //-----------------------------------------------------------

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddService([FromForm] ServiceCreate service)
        {
            try
            {
                if (service == null || service.PhotoUrl == null)
                    return BadRequest("Service data or photo is required");

                var uploadPath = _config["StoredFilesPath"];
                if (!Directory.Exists(uploadPath))
                    Directory.CreateDirectory(uploadPath);

                var extension = Path.GetExtension(service.PhotoUrl.FileName);
                var imageName = Guid.NewGuid().ToString() + extension;
                var filePath = Path.Combine(uploadPath, imageName);

                using (var stream = System.IO.File.Create(filePath))
                {
                    await service.PhotoUrl.CopyToAsync(stream);
                }

                var services = new Service
                {
                    PhotoUrl = imageName,
                    ServiceType = service.ServiceType,
                    ServiceName = service.ServiceName,
                    Description = service.Description,
                    IsDeleted = false,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                _context.Services.Add(services);
                await _context.SaveChangesAsync();

                return Ok(new { message = "Service added successfully", service = services });
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //--------------------------- PUT ---------------------------
        //-----------------------------------------------------------

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateService(int id, [FromForm] ServiceCreate service)
        {
            try
            {
                var editService = await _context.Services.FindAsync(id);
                if (editService == null)
                    return NotFound("Service not found");

                // update non-image fields
                editService.ServiceType = service.ServiceType;
                editService.ServiceName = service.ServiceName;
                editService.Description = service.Description;
                editService.UpdatedAt = DateTime.Now;

                // Only update image if a new one is uploaded
                if (service.PhotoUrl != null && service.PhotoUrl.Length > 0)
                {
                    var uploadPath = _config["StoredFilesPath"];
                    if (!Directory.Exists(uploadPath))
                        Directory.CreateDirectory(uploadPath);

                    var extension = Path.GetExtension(service.PhotoUrl.FileName);
                    var imageName = Guid.NewGuid().ToString() + extension;
                    var filePath = Path.Combine(uploadPath, imageName);

                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await service.PhotoUrl.CopyToAsync(stream);
                    }

                    // delete old image if it exists
                    if (!string.IsNullOrEmpty(editService.PhotoUrl))
                    {
                        var oldImagePath = Path.Combine(uploadPath, editService.PhotoUrl);
                        if (System.IO.File.Exists(oldImagePath))
                        {
                            System.IO.File.Delete(oldImagePath);
                        }
                    }

                    // Assign the new image
                    editService.PhotoUrl = imageName;
                }

                _context.Services.Update(editService);
                await _context.SaveChangesAsync();

                return Ok(new { message = "Service updated successfully", service = editService });
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //----------------------- DELETE ----------------------------
        //-----------------------------------------------------------

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public IActionResult DeleteService(int id)
        {
            try
            {
                var deleteService = _context.Services.Find(id);
                if (deleteService == null)
                    return NotFound("Service not found");

                deleteService.IsDeleted = true;
                _context.Services.Update(deleteService);
                _context.SaveChanges();

                return Ok(new { message = "Service deleted successfully" });
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        //----------------------- GET -------------------------------
        //-----------------------------------------------------------

        [HttpGet]
        public IActionResult GetService()
        {
            try
            {
                var services = _context.Services
                    .Where(s => s.IsDeleted == false)
                    .Select(s => new ServiceDTO
                    {
                        ServiceId = s.ServiceId,
                        // return full URL for photo
                        PhotoUrl = !string.IsNullOrEmpty(s.PhotoUrl)
                            ? $"{Request.Scheme}://{Request.Host}/uploads/{s.PhotoUrl}"
                            : null,
                        ServiceType = s.ServiceType,
                        ServiceName = s.ServiceName,
                        Description = s.Description,
                        IsDeleted = s.IsDeleted,
                        CreatedAt = s.CreatedAt,
                        UpdatedAt = s.UpdatedAt
                    })
                    .ToList();

                if (!services.Any())
                    return NotFound("No services found");

                return Ok(services);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //------------------------------------------------------------
        //------------------- GET BY ID ------------------------------
        //------------------------------------------------------------

        [HttpGet("{id}")]
        public IActionResult GetServiceById(int id)
        {
            try
            {
                var service = _context.Services
                    .Where(s => s.ServiceId == id && s.IsDeleted == false)
                    .Select(s => new ServiceDTO
                    {
                        ServiceId = s.ServiceId,
                        PhotoUrl = !string.IsNullOrEmpty(s.PhotoUrl)
                            ? $"{Request.Scheme}://{Request.Host}/uploads/{s.PhotoUrl}"
                            : null,
                        ServiceType = s.ServiceType,
                        ServiceName = s.ServiceName,
                        Description = s.Description,
                        IsDeleted = s.IsDeleted,
                        CreatedAt = s.CreatedAt,
                        UpdatedAt = s.UpdatedAt
                    })
                    .FirstOrDefault();

                if (service == null)
                    return NotFound("Service not found");

                return Ok(service);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }
    }
}
