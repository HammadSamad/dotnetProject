﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Mvc;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BranchController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;

        public BranchController(StarSecuritiesContext context)
        {
            _context = context;
        }

        //----------------------------------------------------------------
        // POST: Add new Branch
        //----------------------------------------------------------------
        [HttpPost]
        public async Task<IActionResult> AddBranch([FromBody] Branch branch)
        {
            try
            {
                if (branch == null)
                    return BadRequest("Invalid request");

                branch.CreatedAt = DateTime.Now;
                branch.UpdatedAt = DateTime.Now;

                _context.Branches.Add(branch);
                await _context.SaveChangesAsync();

                return Ok(branch); // return the created branch object
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        // PUT: Update Branch
        //----------------------------------------------------------------
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateBranch([FromBody] Branch branch, int id)
        {
            try
            {
                var editBranch = await _context.Branches.FindAsync(id);
                if (editBranch == null)
                    return NotFound("Branch not found");

                editBranch.BranchName = branch.BranchName;
                editBranch.Address = branch.Address;
                editBranch.ContactNumber = branch.ContactNumber;
                editBranch.Email = branch.Email;
                editBranch.UpdatedAt = DateTime.Now;

                await _context.SaveChangesAsync();
                return Ok("Branch updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        // DELETE: Remove Branch
        //----------------------------------------------------------------
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBranch(int id)
        {
            try
            {
                var branch = await _context.Branches.FindAsync(id);
                if (branch == null)
                    return NotFound("Branch not found");

                _context.Branches.Remove(branch);
                await _context.SaveChangesAsync();
                return Ok("Branch deleted successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        // GET: All Branches
        //----------------------------------------------------------------
        [HttpGet]
        public IActionResult GetAllBranches()
        {
            try
            {
                var branches = _context.Branches.ToList();
                if (branches == null || branches.Count == 0)
                    return NotFound("No branches found");

                return Ok(branches);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //----------------------------------------------------------------
        // GET: Branch by ID
        //----------------------------------------------------------------
        [HttpGet("{id}")]
        public IActionResult GetBranchById(int id)
        {
            try
            {
                var branch = _context.Branches.Find(id);
                if (branch == null)
                    return NotFound("Branch not found");

                return Ok(branch);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }
    }
}
