﻿using eproject.Data;
using eproject.Helpers;
using eproject.Models;
using eproject.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;
        private readonly JwtTokenService _jwtTokenService;

        public LoginController(StarSecuritiesContext context, JwtTokenService jwtTokenService)
        {
            _context = context;
            _jwtTokenService = jwtTokenService;
        }

        [HttpPost]
        public IActionResult Login(LoginDTO dto)
        {
            if (dto == null)
                return BadRequest("Invalid login request");

            // Look up login + employee + role, making sure both login and employee are active
            var login = _context.Logins
                .Include(l => l.Employee)
                    .ThenInclude(e => e.Role)
                .FirstOrDefault(l =>
                    l.Username == dto.Username &&
                    l.IsDeleted == false &&
                    l.Employee.IsDeleted == false); // employee must also be active

            if (login == null)
                return Unauthorized("Invalid username or password");

            // verify password hash
            if (!PasswordHasher.VerifyPassword(dto.Password, login.PasswordHash))
                return Unauthorized("Invalid username or password");

            // build role list for JWT
            var roles = new List<string> { login.Employee.Role.RoleName };

            // generate JWT token
            var token = _jwtTokenService.GenerateToken(login, roles);

            // build response DTO
            var response = new LoginResponseDTO
            {
                EmployeeId = login.EmployeeId,
                EmployeeCode = login.Employee.EmployeeCode ?? "",
                Username = login.Username,
                EmployeeName = login.Employee.EmployeeName,
                RoleName = login.Employee.Role.RoleName,
                PhotoUrl = login.Employee.PhotoUrl
            };

            // return token + user info
            return Ok(new
            {
                token,
                user = response
            });
        }
    }
}
