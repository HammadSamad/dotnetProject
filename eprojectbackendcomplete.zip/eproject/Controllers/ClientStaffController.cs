﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientStaffController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;

        public ClientStaffController(StarSecuritiesContext context)
        {
            _context = context;
        }

        // POST: api/ClientStaff
        [HttpPost]
        public IActionResult AddClientStaff([FromBody] ClientStaffCreate clientStaff)
        {
            if (clientStaff == null)
                return BadRequest("Invalid request");

            var client = _context.Clients.FirstOrDefault(c => c.ClientId == clientStaff.ClientId);
            if (client == null)
                return NotFound("Client not found");
            if (client.IsDeleted)
                return BadRequest("Cannot add staff to a deleted client.");

            var employee = _context.Employees.FirstOrDefault(e => e.EmployeeId == clientStaff.EmployeeId);
            if (employee == null)
                return NotFound("Employee not found");
            if (employee.IsDeleted)
                return BadRequest("Cannot assign a deleted employee to a client.");

            var newClientStaff = new ClientStaff
            {
                ClientId = clientStaff.ClientId,
                EmployeeId = clientStaff.EmployeeId,
                IsDeleted = false,
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now
            };

            _context.ClientStaffs.Add(newClientStaff);
            _context.SaveChanges();

            return Ok("Client staff added successfully");
        }

        // PUT: api/ClientStaff/5
        [HttpPut("{id}")]
        public IActionResult UpdateClientStaff(int id, [FromBody] ClientStaffCreate updateClientStaff)
        {
            var editClientStaff = _context.ClientStaffs.Find(id);
            if (editClientStaff == null)
                return NotFound("Client staff not found");

            var client = _context.Clients.FirstOrDefault(c => c.ClientId == updateClientStaff.ClientId);
            if (client == null)
                return NotFound("Client not found");
            if (client.IsDeleted)
                return BadRequest("Cannot assign staff to a deleted client.");

            var employee = _context.Employees.FirstOrDefault(e => e.EmployeeId == updateClientStaff.EmployeeId);
            if (employee == null)
                return NotFound("Employee not found");
            if (employee.IsDeleted)
                return BadRequest("Cannot assign a deleted employee to a client.");

            editClientStaff.ClientId = updateClientStaff.ClientId;
            editClientStaff.EmployeeId = updateClientStaff.EmployeeId;
            editClientStaff.UpdatedAt = DateTime.Now;

            _context.SaveChanges();
            return Ok("Client staff updated successfully");
        }

        // DELETE: api/ClientStaff/5 (soft delete)
        [HttpDelete("{id}")]
        public IActionResult DeleteClientStaff(int id)
        {
            var deleteClientStaff = _context.ClientStaffs.Find(id);
            if (deleteClientStaff == null)
                return NotFound("Client staff not found");

            deleteClientStaff.IsDeleted = true;
            deleteClientStaff.UpdatedAt = DateTime.Now;
            _context.SaveChanges();
            return Ok("Client staff deleted successfully");
        }

        // GET: api/ClientStaff
        [HttpGet]
        public IActionResult GetClientStaff()
        {
            var clientStaff = _context.ClientStaffs
                .Include(cs => cs.Client)
                .Include(cs => cs.Employee)
                .Where(cs => !cs.IsDeleted &&
                             !cs.Client.IsDeleted &&
                             !cs.Employee.IsDeleted)
                .Select(cs => new ClientStaffDTO
                {
                    ClientStaffId = cs.ClientStaffId,
                    ClientId = cs.ClientId,
                    ClientName = cs.Client.ClientName,
                    EmployeeId = cs.EmployeeId,
                    EmployeeName = cs.Employee.EmployeeName,
                    IsDeleted = cs.IsDeleted,
                    CreatedAt = cs.CreatedAt,
                    UpdatedAt = cs.UpdatedAt
                })
                .ToList();

            if (clientStaff.Count == 0)
                return NotFound("No client staff found");

            return Ok(clientStaff);
        }

        // GET: api/ClientStaff/5
        [HttpGet("{id}")]
        public IActionResult GetClientStaffById(int id)
        {
            var clientStaff = _context.ClientStaffs
                .Include(cs => cs.Client)
                .Include(cs => cs.Employee)
                .Where(cs => cs.ClientStaffId == id &&
                             !cs.IsDeleted &&
                             !cs.Client.IsDeleted &&
                             !cs.Employee.IsDeleted)
                .Select(cs => new ClientStaffDTO
                {
                    ClientStaffId = cs.ClientStaffId,
                    ClientId = cs.ClientId,
                    ClientName = cs.Client.ClientName,
                    EmployeeId = cs.EmployeeId,
                    EmployeeName = cs.Employee.EmployeeName,
                    IsDeleted = cs.IsDeleted,
                    CreatedAt = cs.CreatedAt,
                    UpdatedAt = cs.UpdatedAt
                })
                .FirstOrDefault();

            if (clientStaff == null)
                return NotFound("Client staff not found");

            return Ok(clientStaff);
        }
    }
}
