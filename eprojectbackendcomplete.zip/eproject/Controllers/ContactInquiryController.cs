﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Mvc;

[Route("api/[controller]")]
[ApiController]
public class ContactInquiryController : ControllerBase
{
    private readonly StarSecuritiesContext _context;

    public ContactInquiryController(StarSecuritiesContext context)
    {
        _context = context;
    }

    [HttpPost]
    public IActionResult AddContactInquiry(ContactInquiry contactInquiry)
    {
        try
        {
            if (contactInquiry == null)
                return BadRequest("Invalid request");

            contactInquiry.CreatedAt = DateTime.Now;
            contactInquiry.UpdatedAt = DateTime.Now;

            _context.ContactInquiries.Add(contactInquiry);
            _context.SaveChanges();

            return Ok("Contact Inquiry added successfully");
        }
        catch (Exception error)
        {
            return BadRequest(error.Message);
        }
    }

    [HttpPut("{id}")]
    public IActionResult UpdateContactInquiry(int id, ContactInquiry contactInquiry)
    {
        try
        {
            var editContactInquiry = _context.ContactInquiries.Find(id);
            if (editContactInquiry == null)
                return NotFound("Contact Inquiry not found");

            editContactInquiry.Name = contactInquiry.Name;
            editContactInquiry.Email = contactInquiry.Email;
            editContactInquiry.Phone = contactInquiry.Phone;
            editContactInquiry.Message = contactInquiry.Message;
            editContactInquiry.UpdatedAt = DateTime.Now;

            _context.SaveChanges();
            return Ok("Contact Inquiry updated successfully");
        }
        catch (Exception error)
        {
            return BadRequest(error.Message);
        }
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteContactInquiry(int id)
    {
        try
        {
            var deleteContactInquiry = _context.ContactInquiries.Find(id);
            if (deleteContactInquiry == null)
                return NotFound("Contact Inquiry not found");

            _context.ContactInquiries.Remove(deleteContactInquiry);
            _context.SaveChanges();
            return Ok("Contact Inquiry deleted successfully");
        }
        catch (Exception error)
        {
            return BadRequest(error.Message);
        }
    }

    [HttpGet]
    public IActionResult GetAllContactInquiries()
    {
        try
        {
            var contactInquiries = _context.ContactInquiries.ToList();
            if (!contactInquiries.Any())
                return NotFound("No Contact Inquiries found");

            return Ok(contactInquiries);
        }
        catch (Exception error)
        {
            return BadRequest(error.Message);
        }
    }

    [HttpGet("{id}")]
    public IActionResult GetContactInquiryById(int id)
    {
        try
        {
            var contactInquiry = _context.ContactInquiries.Find(id);
            if (contactInquiry == null)
                return NotFound("Contact Inquiry not found");

            return Ok(contactInquiry);
        }
        catch (Exception error)
        {
            return BadRequest(error.Message);
        }
    }
}
