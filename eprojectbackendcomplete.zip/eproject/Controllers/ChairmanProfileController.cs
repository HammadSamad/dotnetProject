﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Mvc;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChairmanProfileController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;
        private readonly IConfiguration _config;

        public ChairmanProfileController(StarSecuritiesContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        //-----------------------------------------------------------
        // POST: Create Chairman Profile (with image upload)
        //-----------------------------------------------------------
        [HttpPost]
        public async Task<IActionResult> AddChairmanProfile([FromForm] ChairmanProfileCreate chairmanProfile)
        {
            try
            {
                if (chairmanProfile == null)
                    return BadRequest("Invalid request");

                if (chairmanProfile.PhotoUrl == null)
                    return BadRequest("Photo is required");

                var uploadPath = _config["StoredFilesPath"];
                if (!Directory.Exists(uploadPath))
                    Directory.CreateDirectory(uploadPath);

                var extension = Path.GetExtension(chairmanProfile.PhotoUrl.FileName);
                var imageName = Guid.NewGuid() + extension;
                var filePath = Path.Combine(uploadPath, imageName);

                using (var stream = System.IO.File.Create(filePath))
                {
                    await chairmanProfile.PhotoUrl.CopyToAsync(stream);
                }

                var chairmanProfileData = new ChairmanProfile
                {
                    Name = chairmanProfile.Name,
                    Bio = chairmanProfile.Bio,
                    PhotoUrl = imageName,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                _context.ChairmanProfiles.Add(chairmanProfileData);
                await _context.SaveChangesAsync();

                var dto = new ChairmanProfileDTO
                {
                    ChairmanId = chairmanProfileData.ChairmanId,
                    Name = chairmanProfileData.Name,
                    Bio = chairmanProfileData.Bio,
                    PhotoUrl = chairmanProfileData.PhotoUrl,
                    CreatedAt = chairmanProfileData.CreatedAt,
                    UpdatedAt = chairmanProfileData.UpdatedAt
                };

                return Ok(dto);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        // PUT: Update Chairman Profile (image optional)
        //-----------------------------------------------------------
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateChairmanProfile([FromForm] ChairmanProfileCreate updateChairmanProfile, int id)
        {
            try
            {
                var editChairmanProfile = await _context.ChairmanProfiles.FindAsync(id);
                if (editChairmanProfile == null)
                    return NotFound("Chairman profile not found");

                editChairmanProfile.Name = updateChairmanProfile.Name;
                editChairmanProfile.Bio = updateChairmanProfile.Bio;
                editChairmanProfile.UpdatedAt = DateTime.Now;

                if (updateChairmanProfile.PhotoUrl != null && updateChairmanProfile.PhotoUrl.Length > 0)
                {
                    var uploadPath = _config["StoredFilesPath"];
                    if (!Directory.Exists(uploadPath))
                        Directory.CreateDirectory(uploadPath);

                    var extension = Path.GetExtension(updateChairmanProfile.PhotoUrl.FileName);
                    var imageName = Guid.NewGuid() + extension;
                    var filePath = Path.Combine(uploadPath, imageName);

                    using (var stream = System.IO.File.Create(filePath))
                    {
                        await updateChairmanProfile.PhotoUrl.CopyToAsync(stream);
                    }

                    // Delete old image if exists
                    if (!string.IsNullOrEmpty(editChairmanProfile.PhotoUrl))
                    {
                        var oldImagePath = Path.Combine(uploadPath, editChairmanProfile.PhotoUrl);
                        if (System.IO.File.Exists(oldImagePath))
                            System.IO.File.Delete(oldImagePath);
                    }

                    editChairmanProfile.PhotoUrl = imageName;
                }

                _context.ChairmanProfiles.Update(editChairmanProfile);
                await _context.SaveChangesAsync();

                return Ok("Chairman profile updated successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        // DELETE: Remove Chairman Profile
        //-----------------------------------------------------------
        [HttpDelete("{id}")]
        public async Task<IActionResult> DelChairmanProfile(int id)
        {
            try
            {
                var delChairmanProfile = await _context.ChairmanProfiles.FindAsync(id);
                if (delChairmanProfile == null)
                    return NotFound("Chairman profile not found");

                _context.ChairmanProfiles.Remove(delChairmanProfile);
                await _context.SaveChangesAsync();

                return Ok("Chairman profile deleted successfully");
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //-----------------------------------------------------------
        // GET: All Chairman Profiles
        //-----------------------------------------------------------
        [HttpGet]
        public IActionResult GetChairmanProfile()
        {
            var profiles = _context.ChairmanProfiles
                .Select(cp => new ChairmanProfileDTO
                {
                    ChairmanId = cp.ChairmanId,
                    Name = cp.Name,
                    Bio = cp.Bio,
                    PhotoUrl = cp.PhotoUrl,
                    CreatedAt = cp.CreatedAt,
                    UpdatedAt = cp.UpdatedAt
                })
                .ToList();

            return profiles.Any() ? Ok(profiles) : NotFound("No chairman profiles found");
        }


        //-----------------------------------------------------------
        // GET: Chairman Profile by ID
        //-----------------------------------------------------------
        [HttpGet("{id}")]
        public IActionResult GetChairmanProfileById(int id)
        {
            try
            {
                var data = _context.ChairmanProfiles
                    .Where(cp => cp.ChairmanId == id)
                    .Select(cp => new ChairmanProfileDTO
                    {
                        ChairmanId = cp.ChairmanId,
                        Name = cp.Name,
                        Bio = cp.Bio,
                        PhotoUrl = cp.PhotoUrl,
                        CreatedAt = cp.CreatedAt,
                        UpdatedAt = cp.UpdatedAt
                    })
                    .FirstOrDefault();

                if (data == null)
                    return NotFound("Chairman profile not found");

                return Ok(data);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }
    }
}
