﻿using eproject.Data;
using eproject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientServiceController : ControllerBase
    {
        private readonly StarSecuritiesContext _context;

        public ClientServiceController(StarSecuritiesContext context)
        {
            _context = context;
        }

        // POST: api/ClientService
        [HttpPost]
        public IActionResult AddClientService([FromBody] ClientServiceCreate clientService)
        {
            if (clientService == null)
                return BadRequest("Invalid request");

            var client = _context.Clients.FirstOrDefault(c => c.ClientId == clientService.ClientId);
            if (client == null)
                return NotFound("Client not found");
            if (client.IsDeleted)
                return BadRequest("Cannot add service to a deleted client.");

            var newClientService = new ClientService
            {
                ClientId = clientService.ClientId,
                ServiceId = clientService.ServiceId,
                IsDeleted = false,
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now
            };

            _context.ClientServices.Add(newClientService);
            _context.SaveChanges();

            return Ok("Client Service added successfully");
        }

        // PUT: api/ClientService/5
        [HttpPut("{id}")]
        public IActionResult UpdateClientService(int id, [FromBody] ClientServiceCreate updateClientService)
        {
            var editClientService = _context.ClientServices.Find(id);
            if (editClientService == null)
                return NotFound("Client Service not found");

            var client = _context.Clients.FirstOrDefault(c => c.ClientId == updateClientService.ClientId);
            if (client == null)
                return NotFound("Client not found");
            if (client.IsDeleted)
                return BadRequest("Cannot assign a deleted client to this service.");

            editClientService.ClientId = updateClientService.ClientId;
            editClientService.ServiceId = updateClientService.ServiceId;
            editClientService.UpdatedAt = DateTime.Now;

            _context.SaveChanges();

            return Ok("Client Service updated successfully");
        }

        // DELETE: api/ClientService/5 (soft delete)
        [HttpDelete("{id}")]
        public IActionResult DeleteClientService(int id)
        {
            var deleteClientService = _context.ClientServices.Find(id);
            if (deleteClientService == null)
                return NotFound("Client Service not found");

            deleteClientService.IsDeleted = true;
            deleteClientService.UpdatedAt = DateTime.Now;
            _context.SaveChanges();

            return Ok("Client Service deleted successfully");
        }

        // GET: api/ClientService
        [HttpGet]
        public IActionResult GetClientServices()
        {
            var clientData = _context.ClientServices
                .Include(cd => cd.Client)
                .Include(cd => cd.Service)
                .Where(cd => !cd.IsDeleted &&
                             !cd.Client.IsDeleted &&
                             !cd.Service.IsDeleted)
                .Select(cd => new ClientServiceDTO
                {
                    ClientServiceId = cd.ClientServiceId,
                    ClientId = cd.ClientId,
                    ClientName = cd.Client.ClientName,
                    ServiceId = cd.ServiceId,
                    ServiceName = cd.Service.ServiceName,
                    IsDeleted = cd.IsDeleted,
                    CreatedAt = cd.CreatedAt,
                    UpdatedAt = cd.UpdatedAt
                })
                .ToList();

            if (clientData.Count == 0)
                return NotFound("No Client Services found");

            return Ok(clientData);
        }

        // GET: api/ClientService/5
        [HttpGet("{id}")]
        public IActionResult GetClientServiceById(int id)
        {
            var clientService = _context.ClientServices
                .Include(cd => cd.Client)
                .Include(cd => cd.Service)
                .Where(cs => cs.ClientServiceId == id &&
                             !cs.IsDeleted &&
                             !cs.Client.IsDeleted &&
                             !cs.Service.IsDeleted)
                .Select(cs => new ClientServiceDTO
                {
                    ClientServiceId = cs.ClientServiceId,
                    ClientId = cs.ClientId,
                    ClientName = cs.Client.ClientName,
                    ServiceId = cs.ServiceId,
                    ServiceName = cs.Service.ServiceName,
                    IsDeleted = cs.IsDeleted,
                    CreatedAt = cs.CreatedAt,
                    UpdatedAt = cs.UpdatedAt
                })
                .FirstOrDefault();

            if (clientService == null)
                return NotFound("Client Service not found");

            return Ok(clientService);
        }
    }
}
