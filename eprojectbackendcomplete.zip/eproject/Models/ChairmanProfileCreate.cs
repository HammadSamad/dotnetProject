﻿namespace eproject.Models
{
    public class ChairmanProfileCreate
    {
        public int ChairmanId { get; set; }

        public string Name { get; set; } = null!;

        public string Bio { get; set; } = null!;

        public IFormFile? PhotoUrl { get; set; }

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }
}
