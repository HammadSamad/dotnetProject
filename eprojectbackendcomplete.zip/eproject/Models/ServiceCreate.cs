﻿namespace eproject.Models
{
    public class ServiceCreate
    {
        public int ServiceId { get; set; }

        public IFormFile? PhotoUrl { get; set; }

        public string ServiceType { get; set; } = null!;

        public string ServiceName { get; set; } = null!;

        public string Description { get; set; } = null!;

        public bool IsDeleted { get; set; }

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }
}
