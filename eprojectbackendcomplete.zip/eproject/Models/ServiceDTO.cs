﻿namespace eproject.Models
{
    public class ServiceDTO
    {
        public int ServiceId { get; set; }

        public string? PhotoUrl { get; set; }

        public string ServiceType { get; set; } = null!;

        public string ServiceName { get; set; } = null!;

        public string Description { get; set; } = null!;

        public bool IsDeleted { get; set; }

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }
}
