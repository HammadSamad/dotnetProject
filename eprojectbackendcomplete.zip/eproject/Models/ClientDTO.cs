﻿namespace eproject.Models
{
    public class ClientDTO
    {
        public int ClientId { get; set; }

        public string ClientName { get; set; } = null!;

        public string ClientEmail { get; set; } = null!;

        public string? PhotoUrl { get; set; }

        public string ClientNumber { get; set; } = null!;

        public string ClientAddress { get; set; } = null!;

        public bool IsDeleted { get; set; }

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }
}
