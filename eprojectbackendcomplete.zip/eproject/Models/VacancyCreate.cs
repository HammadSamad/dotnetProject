﻿namespace eproject.Models
{
    public class VacancyCreate
    {
        public int VacancyId { get; set; }

        public string Title { get; set; } = null!;

        public int DepartmentId { get; set; }

        public string Description { get; set; } = null!;

        public DateOnly? OpeningDate { get; set; }

        public DateOnly? ClosingDate { get; set; }

        public string Status { get; set; } = null!;

        public bool IsDeleted { get; set; }

        public DateTime? CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; set; }
    }
}
